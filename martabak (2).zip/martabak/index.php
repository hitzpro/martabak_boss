<?php
// Redirect ke halaman lain, misalnya ke 'home.php'
header("Location: pages/index.php");
exit(); // Penting untuk menghentikan eksekusi setelah redirect
?>
