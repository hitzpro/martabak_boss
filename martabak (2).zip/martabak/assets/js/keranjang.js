document.addEventListener('DOMContentLoaded', function () {
    // Elements
    const cartItemsContainer = document.getElementById('cartItems');
    const detailContainer = document.getElementById('detailContainer');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const emptyCartMessage = document.querySelector('.cart-empty');
    const paginationContainer = document.getElementById('cartPagination');

    // Pagination variables
    const itemsPerPage = 4;
    let currentPage = 1;
    let cartItems = [];
    let totalPages = 0;

    // Initialize
    fetchCartItems();
    
    // Fetch cart items from the server
    function fetchCartItems() {
        fetch('../../logic/public/get_keranjang.php')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.items && data.items.length > 0) {
                    cartItems = data.items;
                    totalPages = Math.ceil(cartItems.length / itemsPerPage);
                    renderCartItems();
                    updatePaginationButtons();
                    bindItemEvents();
                } else {
                    showEmptyCart();
                }
            })
            .catch(error => {
                console.error('Error fetching cart items:', error);
                showEmptyCart();
            });
    }

    function showEmptyCart() {
        // Clear cart items container
        cartItemsContainer.innerHTML = '';
        
        // Show empty cart message
        emptyCartMessage.style.display = 'block';
        
        // Hide pagination
        paginationContainer.style.display = 'none';
    }

    // Render cart items for current page
    function renderCartItems() {
        // Clear existing items
        cartItemsContainer.innerHTML = '';
        
        // Calculate start and end index for current page
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = Math.min(startIndex + itemsPerPage, cartItems.length);
        
        // Display items for current page
        for (let i = startIndex; i < endIndex; i++) {
            const item = cartItems[i];
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.setAttribute('data-id', item.id);
            itemElement.setAttribute('data-produk-id', item.produk_id);
            
            // Format price to IDR
            const formattedPrice = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            }).format(item.harga * item.jumlah);
            
            itemElement.innerHTML = `
                <div class="item-name">${item.nama_produk}</div>
                <div class="item-quantity">${item.jumlah}</div>
                <div class="item-price">${formattedPrice}</div>
                <div class="item-actions">
                    <button class="btn btn-order" data-id="${item.id}" data-produk-id="${item.produk_id}">Pesan Sekarang</button>
                    <button class="btn btn-delete" data-id="${item.id}">Hapus</button>
                </div>
            `;
            
            cartItemsContainer.appendChild(itemElement);
        }
        
        // Show message if no items
        if (cartItems.length === 0) {
            showEmptyCart();
        }
    }

    // Update pagination buttons state
    function updatePaginationButtons() {
        prevBtn.disabled = currentPage === 1;
        nextBtn.disabled = currentPage === totalPages;
        
        // Hide pagination if only one page or no items
        paginationContainer.style.display = (totalPages <= 1) ? 'none' : 'flex';
    }

    // Bind events to cart items
    function bindItemEvents() {
        // Bind hover events for detail display
        const cartItems = document.querySelectorAll('.cart-item');
        cartItems.forEach(item => {
            item.addEventListener('mouseenter', function() {
                const itemId = this.getAttribute('data-id');
                const produkId = this.getAttribute('data-produk-id');
                showItemDetail(itemId, produkId);
            });
        });
        
        // Bind click events for buttons
        const orderButtons = document.querySelectorAll('.btn-order');
        const deleteButtons = document.querySelectorAll('.btn-delete');
        
        orderButtons.forEach(button => {
            button.addEventListener('click', function() {
                const produkId = this.getAttribute('data-produk-id');
                window.location.href = `checkout.php?id=${produkId}`;
            });
        });
        
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const itemId = this.getAttribute('data-id');
                removeFromCart(itemId);
            });
        });
    }

    // Show item detail on hover
    function showItemDetail(itemId, produkId) {
        fetch(`../../logic/public/get_produk_detail.php?id=${produkId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const product = data.product;
                    detailContainer.innerHTML = `
                        <h2>${product.nama}</h2>
                        <div class="product-image">
                            <img src="${product.gambar}" alt="${product.nama}" width="100%">
                        </div>
                        <p class="product-description">${product.deskripsi}</p>
                        <p class="product-price">Harga: Rp ${parseInt(product.harga).toLocaleString()}</p>
                    `;
                }
            })
            .catch(error => {
                console.error('Error fetching product detail:', error);
            });
    }

    // Remove item from cart
    function removeFromCart(itemId) {
        const formData = new FormData();
        formData.append('id', itemId);
        
        fetch('../../logic/public/remove_from_cart.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Produk berhasil dihapus dari keranjang!');
                // Refresh cart items
                fetchCartItems();
            } else {
                alert(data.message || 'Gagal menghapus produk dari keranjang.');
            }
        })
        .catch(error => {
            console.error('Error removing item from cart:', error);
            alert('Terjadi kesalahan. Silakan coba lagi.');
        });
    }

    // Pagination event listeners
    prevBtn.addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            renderCartItems();
            updatePaginationButtons();
            bindItemEvents();
        }
    });
    
    nextBtn.addEventListener('click', function() {
        if (currentPage < totalPages) {
            currentPage++;
            renderCartItems();
            updatePaginationButtons();
            bindItemEvents();
        }
    });
});