document.addEventListener('DOMContentLoaded', function () {
    // Carousel Elements
    const carousel = document.getElementById('productCarousel');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const paginationContainer = document.getElementById('carouselPagination');

    // Accordion Elements
    const accordionItems = document.querySelectorAll('.mnd-accordion-item');

    // Search Elements
    const searchInput = document.querySelector('.mnd-search-input');
    const searchBtn = document.querySelector('.mnd-search-btn');

    // Global Variables
    let originalProducts = [];
    let filteredProducts = [];
    let currentPage = 0;
    let cardsPerPage = getCardsPerPage();

    // Check if carousel elements exist
    if (!carousel || !prevBtn || !nextBtn || !paginationContainer) {
        console.error("Elemen carousel atau tombol navigasi tidak ditemukan.");
        return;
    }

    // Initialize All Features
    initCarousel();
    initAccordion();
    initSmoothScroll();
    initSearch();
    initLoginButtons();
    initRunningText();

    // --- CAROUSEL ---
    function initCarousel() {
        fetch('../logic/public/get_produk1.php')
            .then(res => res.json())
            .then(data => {
                originalProducts = data;
                filteredProducts = [...originalProducts];
                renderCarousel(filteredProducts);
            })
            .catch(err => {
                console.error('Gagal mengambil produk:', err);
            });

        document.addEventListener('searchPerformed', function (e) {
            currentPage = 0;
            renderCarousel(e.detail.products);
        });

        prevBtn.addEventListener('click', () => {
            if (currentPage > 0) {
                currentPage--;
                renderCarousel(filteredProducts);
            }
        });

        nextBtn.addEventListener('click', () => {
            const maxSlide = Math.ceil(filteredProducts.length / cardsPerPage) - 1;
            if (currentPage < maxSlide) {
                currentPage++;
                renderCarousel(filteredProducts);
            }
        });

        window.addEventListener('resize', () => {
            cardsPerPage = getCardsPerPage();
            renderCarousel(filteredProducts);
        });
    }

    function renderCarousel(products) {
        carousel.innerHTML = '';
        const totalPages = Math.ceil(products.length / cardsPerPage);
        const start = currentPage * cardsPerPage;
        const end = start + cardsPerPage;
        const currentProducts = products.slice(start, end);

        currentProducts.forEach(p => {
            const el = document.createElement('div');
            el.className = 'mnd-product-card';
            el.innerHTML = `
                <div class="mnd-product-img">
                    <img src="${p.gambar}" alt="${p.nama}" style="width:100%;height:auto;border-radius:10px;">
                </div>
                <div class="mnd-product-details">
                    <h3>${p.nama}</h3>
                    <h4>Rp ${parseInt(p.harga).toLocaleString()}</h4>
                    <p>${p.deskripsi}</p>
                    <div class="mnd-product-actions">
                        <button class="mnd-buy-btn">Beli Sekarang</button>
                        <button class="mnd-add-btn">+</button>
                    </div>
                </div>
            `;
            carousel.appendChild(el);
        });

        bindProductButtons();
        createPaginationDots(totalPages);
        updatePaginationDots(currentPage);
        updateNavButtons(currentPage, totalPages);
    }

    function getCardsPerPage() {
        if (window.innerWidth < 768) return 1;
        if (window.innerWidth < 992) return 2;
        return 3;
    }

    function createPaginationDots(totalPages) {
        paginationContainer.innerHTML = '';
        for (let i = 0; i < totalPages; i++) {
            const dot = document.createElement('div');
            dot.className = 'mnd-pagination-dot';
            if (i === currentPage) dot.classList.add('active');
            dot.addEventListener('click', () => {
                currentPage = i;
                renderCarousel(filteredProducts);
            });
            paginationContainer.appendChild(dot);
        }
    }

    function updatePaginationDots(activeIndex) {
        const dots = paginationContainer.querySelectorAll('.mnd-pagination-dot');
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === activeIndex);
        });
    }

    function updateNavButtons(current, totalPages) {
        prevBtn.style.opacity = current === 0 ? '0.5' : '1';
        prevBtn.style.cursor = current === 0 ? 'default' : 'pointer';

        nextBtn.style.opacity = current === totalPages - 1 ? '0.5' : '1';
        nextBtn.style.cursor = current === totalPages - 1 ? 'default' : 'pointer';
    }

    function bindProductButtons() {
        const buyButtons = document.querySelectorAll('.mnd-buy-btn');
        const addButtons = document.querySelectorAll('.mnd-add-btn');
    
        buyButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                redirectToLogin();
            });
        });
    
        addButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                redirectToLogin();
            });
        });
    }
    
    

    // --- ACCORDION ---
    function initAccordion() {
        accordionItems.forEach(item => {
            const header = item.querySelector('.mnd-accordion-header');
            header?.addEventListener('click', () => {
                accordionItems.forEach(other => {
                    if (other !== item && other.classList.contains('active')) {
                        other.classList.remove('active');
                    }
                });
                item.classList.toggle('active');
            });
        });
    }

    // --- SMOOTH SCROLL ---
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                const targetId = this.getAttribute('href');
                if (targetId !== '#') {
                    const target = document.querySelector(targetId);
                    if (target) {
                        e.preventDefault();
                        window.scrollTo({
                            top: target.offsetTop,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });

        const scrollBtn = document.querySelector('.mnd-scroll-btn');
        scrollBtn?.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const target = document.querySelector(targetId);
            if (target) {
                window.scrollTo({
                    top: target.offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    }

    // --- SEARCH ---
    function initSearch() {
        if (searchBtn) {
            searchBtn.addEventListener('click', performSearch);
        }
        if (searchInput) {
            searchInput.addEventListener('keypress', function (e) {
                if (e.key === 'Enter') performSearch();
            });
        }

        function performSearch() {
            const keyword = searchInput.value.trim().toLowerCase();

            if (!keyword) {
                filteredProducts = [...originalProducts];
                triggerSearchEvent(filteredProducts);
                return;
            }

            const result = originalProducts.filter(p => {
                const nama = (p.nama || '').toLowerCase();
                const deskripsi = (p.deskripsi || '').toLowerCase();
                return nama.includes(keyword) || deskripsi.includes(keyword);
            });

            if (result.length === 0) {
                alert('Tidak ada produk yang cocok dengan pencarian Anda.');
                return;
            }

            filteredProducts = result;
            triggerSearchEvent(filteredProducts);
        }

        function triggerSearchEvent(products) {
            const event = new CustomEvent('searchPerformed', { detail: { products } });
            document.dispatchEvent(event);
        }
    }

    // --- LOGIN BUTTON ---
    function initLoginButtons() {
        const loginBtn = document.querySelector('.mnd-login-btn');
        loginBtn?.addEventListener('click', function (e) {
            e.preventDefault();
            redirectToLogin();
        });
    }

    // --- RUNNING TEXT ---
    function initRunningText() {
        const runningText = document.querySelector('.mnd-running-text-content');
        if (runningText) {
            runningText.innerHTML += runningText.innerHTML;
            const textLength = runningText.textContent.length;
            const duration = Math.max(20, textLength / 10);
            runningText.style.animationDuration = `${duration}s`;
        }
    }

    // --- REDIRECT ---
    function redirectToLogin() {
        window.location.href = 'login.php';
    }
});
