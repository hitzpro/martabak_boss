// SIDEBAR KODE
document.addEventListener('DOMContentLoaded', function() {
    // Select all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    
    // Function to set active menu item
    function setActiveMenu(menuId) {
        // Remove active class from all menu items
        menuItems.forEach(item => {
            item.classList.remove('active');
        });
        
        // Add active class to selected menu item
        const selectedMenu = document.querySelector(`[data-menu="${menuId}"]`);
        if (selectedMenu) {
            selectedMenu.classList.add('active');
        }
    }
    
    // Add click event listeners to menu items
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            const menuId = this.getAttribute('data-menu');
            
            // Handle logout separately
            if (menuId === 'logout') {
                e.preventDefault();  // Prevent navigating for logout
                if (confirm('Apakah Anda yakin ingin keluar?')) {
                    alert('Logout berhasil!');
                    window.location.href = '../logic/logout.php';  // Redirect to logout page
                }
                return;
            }
            
            // For other menu items, allow normal navigation
            setActiveMenu(menuId);
        });
    });
    
    // Set Dashboard as the default active menu
    setActiveMenu('dashboard');
});



document.addEventListener('DOMContentLoaded', function() {
    // Get all action buttons
    const processButtons = document.querySelectorAll('.btn-process');
    const completeButtons = document.querySelectorAll('.btn-complete');
    const detailButtons = document.querySelectorAll('.btn-detail');
    
    // Process button functionality
    processButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            
            // Visual feedback
            row.style.backgroundColor = '#e8f4fd';
            setTimeout(() => {
                row.style.backgroundColor = '';
            }, 1000);
            
            // Update stats (for demonstration)
            const processCount = document.querySelectorAll('.stats-card')[1].querySelector('.stats-number');
            processCount.textContent = parseInt(processCount.textContent) + 1;
            
            // Here you would typically send an AJAX request to update the status in the database
            alert('Pesanan sedang diproses!');
        });
    });
    
    // Complete button functionality
    completeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            
            // Visual feedback
            row.style.backgroundColor = '#e8fdf0';
            setTimeout(() => {
                row.style.backgroundColor = '';
            }, 1000);
            
            // Update stats (for demonstration)
            const completeCount = document.querySelectorAll('.stats-card')[2].querySelector('.stats-number');
            completeCount.textContent = parseInt(completeCount.textContent) + 1;
            
            // Here you would typically send an AJAX request to update the status in the database
            alert('Pesanan telah diselesaikan!');
        });
    });
    
    // Detail button functionality
    detailButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            const orderData = {
                no: row.cells[0].textContent,
                customer: row.cells[1].textContent,
                order: row.cells[2].textContent,
                quantity: row.cells[3].textContent,
                type: row.cells[4].textContent,
                variant: row.cells[5].textContent,
                notes: row.cells[6].textContent,
                address: row.cells[7].textContent
            };
            
            // Show order details (for demonstration)
            showOrderDetails(orderData);
        });
    });
    
    // Function to show order details (modal or expand row)
    function showOrderDetails(data) {
        // Create a simple modal for demo purposes
        const modal = document.createElement('div');
        modal.className = 'order-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <h2>Detail Pesanan #${data.no}</h2>
                <p><strong>Nama Pemesan:</strong> ${data.customer}</p>
                <p><strong>Nama Pesanan:</strong> ${data.order}</p>
                <p><strong>Jumlah:</strong> ${data.quantity}</p>
                <p><strong>Jenis Martabak:</strong> ${data.type}</p>
                <p><strong>Varian Martabak:</strong> ${data.variant}</p>
                <p><strong>Catatan:</strong> ${data.notes}</p>
                <p><strong>Alamat:</strong> ${data.address}</p>
            </div>
        `;
        
        // Add modal styles
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
        modal.style.display = 'flex';
        modal.style.justifyContent = 'center';
        modal.style.alignItems = 'center';
        modal.style.zIndex = '1000';
        
        const modalContent = modal.querySelector('.modal-content');
        modalContent.style.backgroundColor = '#fff';
        modalContent.style.padding = '20px';
        modalContent.style.borderRadius = '8px';
        modalContent.style.width = '90%';
        modalContent.style.maxWidth = '500px';
        
        const closeBtn = modal.querySelector('.close-modal');
        closeBtn.style.float = 'right';
        closeBtn.style.fontSize = '24px';
        closeBtn.style.cursor = 'pointer';
        
        // Close modal on click
        closeBtn.addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        // Close modal when clicking outside
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
            }
        });
        
        document.body.appendChild(modal);
    }
    
    // Optional: Add functionality for statistics cards to make them interactive
    const statsCards = document.querySelectorAll('.stats-card');
    statsCards.forEach(card => {
        card.addEventListener('click', function() {
            const category = this.querySelector('h3').textContent;
            // Could show filtered orders based on status
            alert(`Showing ${category} orders`);
        });
    });
    
    // Optional: Add search and filter functionality
    function setupSearch() {
        // Create search element
        const searchContainer = document.createElement('div');
        searchContainer.className = 'search-container';
        searchContainer.innerHTML = `
            <input type="text" id="orderSearch" placeholder="Cari pesanan...">
            <select id="filterStatus">
                <option value="all">Semua Status</option>
                <option value="new">Baru</option>
                <option value="process">Diproses</option>
                <option value="complete">Selesai</option>
            </select>
        `;
        
        // Style the search container
        searchContainer.style.marginBottom = '20px';
        searchContainer.style.display = 'flex';
        searchContainer.style.gap = '10px';
        
        const searchInput = searchContainer.querySelector('#orderSearch');
        searchInput.style.padding = '8px';
        searchInput.style.borderRadius = '4px';
        searchInput.style.border = '1px solid #ddd';
        searchInput.style.flex = '1';
        
        const filterSelect = searchContainer.querySelector('#filterStatus');
        filterSelect.style.padding = '8px';
        filterSelect.style.borderRadius = '4px';
        filterSelect.style.border = '1px solid #ddd';
        
        // Insert before table container
        const tableContainer = document.querySelector('.table-container');
        tableContainer.parentNode.insertBefore(searchContainer, tableContainer);
    }
    
    // Uncomment to add search functionality
    // setupSearch();
});