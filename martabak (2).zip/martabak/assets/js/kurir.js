document.addEventListener('DOMContentLoaded', function() {
    // Sample delivery data (in a real app, this would come from a database)
    const deliveries = [
        {
            id: 1,
            customerName: 'Nama User',
            orderItems: [
                { name: 'Martabak Manis', quantity: 2, price: 25000 },
                { name: 'Martabak Asin', quantity: 1, price: 28000 }
            ],
            address: 'Jl. Merdeka No. 123, RT 02/RW 03, Kelurahan Sukajadi, Kecamatan Cibeunying, Kota Bandung',
            status: 'pending',
            notes: ''
        },
        {
            id: 2,
            customerName: 'Budi Santoso',
            orderItems: [
                { name: 'Martabak Manis', quantity: 1, price: 25000 },
                { name: 'Martabak Telor', quantity: 1, price: 30000 }
            ],
            address: 'Jl. Asia Afrika No. 45, RT 05/RW 01, Kelurahan Braga, Kecamatan Sumur Bandung, Kota Bandung',
            status: 'picking',
            notes: 'Telepon dulu sebelum datang'
        },
        {
            id: 3,
            customerName: 'Siti Rahayu',
            orderItems: [
                { name: 'Martabak Cokelat', quantity: 3, price: 25000 }
            ],
            address: 'Jl. Gatot Subroto No. 78, RT 08/RW 04, Kelurahan Cibangkong, Kecamatan Batununggal, Kota Bandung',
            status: 'shipping',
            notes: 'Alamat dekat minimarket'
        },
        {
            id: 4,
            customerName: 'Joko Widodo',
            orderItems: [
                { name: 'Martabak Pisang', quantity: 1, price: 25000 },
                { name: 'Martabak Kacang', quantity: 1, price: 25000 }
            ],
            address: 'Jl. Dipatiukur No. 112, RT 03/RW 07, Kelurahan Lebakgede, Kecamatan Coblong, Kota Bandung',
            status: 'delivered',
            notes: 'Sudah diterima oleh penerima'
        }
    ];

    // Get DOM elements
    const tableBody = document.querySelector('.table-body');
    const modal = document.getElementById('statusModal');
    const modalClose = document.querySelector('.close');
    const cancelButton = document.querySelector('.btn-cancel');
    const editForm = document.getElementById('editDeliveryForm');

    // Status label mapping
    const statusLabels = {
        'pending': 'Menunggu Pengiriman',
        'picking': 'Sedang Dijemput',
        'shipping': 'Sedang Dikirim',
        'delivered': 'Sudah Diterima',
        'failed': 'Gagal Dikirim'
    };

    // Format price with thousand separator
    function formatPrice(price) {
        return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }

    // Generate order item text
    function formatOrderItems(items) {
        return items.map(item => 
            `${item.quantity}x ${item.name} (Rp ${formatPrice(item.price * item.quantity)})`
        ).join('<br>');
    }

    // Generate order total
    function calculateTotal(items) {
        return items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    // Render delivery rows
    function renderDeliveries() {
        tableBody.innerHTML = '';
        
        deliveries.forEach((delivery, index) => {
            const deliveryRow = document.createElement('div');
            deliveryRow.className = 'table-row';
            
            deliveryRow.innerHTML = `
                <div class="col-number">${index + 1}</div>
                <div class="col-name">
                    ${delivery.customerName}
                    <div>
                        <span class="status-badge status-${delivery.status}">
                            ${statusLabels[delivery.status]}
                        </span>
                    </div>
                </div>
                <div class="col-address">
                    <div class="address-info">${delivery.address}</div>
                </div>
                <div class="col-action">
                    <button class="status-btn" data-id="${delivery.id}">Ubah Status</button>
                </div>
            `;
            tableBody.appendChild(deliveryRow);
        });

        // Add event listeners to status buttons
        document.querySelectorAll('.status-btn').forEach(button => {
            button.addEventListener('click', function() {
                const deliveryId = parseInt(this.getAttribute('data-id'));
                openStatusModal(deliveryId);
            });
        });
    }

    // Open status modal and populate with delivery data
    function openStatusModal(deliveryId) {
        const delivery = deliveries.find(d => d.id === deliveryId);
        
        if (delivery) {
            document.getElementById('deliveryId').value = delivery.id;
            document.getElementById('customerName').value = delivery.customerName;
            document.getElementById('deliveryAddress').value = delivery.address;
            
            // Format order details for textarea
            const orderDetails = delivery.orderItems.map(item => 
                `${item.quantity}x ${item.name} (Rp ${formatPrice(item.price * item.quantity)})`
            ).join('\n');
            
            const totalPrice = calculateTotal(delivery.orderItems);
            const fullOrderDetails = `${orderDetails}\n\nTotal: Rp ${formatPrice(totalPrice)}`;
            
            document.getElementById('orderDetails').value = fullOrderDetails;
            document.getElementById('deliveryStatus').value = delivery.status;
            document.getElementById('courierNote').value = delivery.notes;
            
            modal.style.display = 'block';
        }
    }

    // Close modal
    function closeModal() {
        modal.style.display = 'none';
        editForm.reset();
    }

    // Handle form submission
    editForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const deliveryId = parseInt(document.getElementById('deliveryId').value);
        const deliveryIndex = deliveries.findIndex(d => d.id === deliveryId);
        
        if (deliveryIndex !== -1) {
            // Update delivery status and notes
            deliveries[deliveryIndex].status = document.getElementById('deliveryStatus').value;
            deliveries[deliveryIndex].notes = document.getElementById('courierNote').value;
            
            // Re-render deliveries and close modal
            renderDeliveries();
            closeModal();
            
            // Show success notification
            showNotification('Status pengiriman berhasil diperbarui!');
        }
    });

    // Show notification function
    function showNotification(message) {
        // Remove existing notification if present
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            document.body.removeChild(existingNotification);
        }
        
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.add('hide');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Event listeners for closing modal
    modalClose.addEventListener('click', closeModal);
    cancelButton.addEventListener('click', closeModal);
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Initialize - render deliveries on page load
    renderDeliveries();
});