document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('statusModal');
    const modalClose = document.querySelector('.close');
    const cancelButton = document.querySelector('.btn-cancel');
    const editForm = document.getElementById('editStatusForm');
    const tableBody = document.querySelector('.table-body');

    const statusLabels = {
        'menunggu konfirmasi': 'Menunggu Konfirmasi',
        'sedang diproses': 'Sedang Diproses',
        'sedang dikirim': 'Sedang Dikirim',
        'dibatalkan': 'Dibatalkan',
        'selesai': 'Selesai'
    };

    // Format harga ke format Rupiah
    function formatPrice(price) {
        return parseInt(price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }

    // Fetch orders from the database
    function loadOrders() {
        fetch('../logic/admin/get_orders.php')
            .then(response => response.json())
            .then(orders => {
                displayOrders(orders);
            })
            .catch(error => {
                console.error('Error loading orders:', error);
                showNotification('Gagal memuat data pesanan');
            });
    }

    // Display orders in the table
    function displayOrders(orders) {
        tableBody.innerHTML = '';
        
        if (orders.length === 0) {
            tableBody.innerHTML = '<div class="no-orders">Tidak ada pesanan</div>';
            return;
        }

        // Filter out orders with status "selesai"
        const activeOrders = orders.filter(order => order.status !== 'selesai');
        
        if (activeOrders.length === 0) {
            tableBody.innerHTML = '<div class="no-orders">Tidak ada pesanan aktif</div>';
            return;
        }

        activeOrders.forEach((order, index) => {
            const row = document.createElement('div');
            row.className = 'table-row';
            
            row.innerHTML = `
                <div class="col-number">${index + 1}</div>
                <div class="col-name">${order.nama_user}</div>
                <div class="col-order">
                    ${order.nama_produk} (${order.jumlah}x) - Rp ${formatPrice(order.harga_total)}
                </div>
                <div class="col-action">
                    <button class="btn-edit" data-id="${order.id}">Edit Status</button>
                </div>
            `;
            
            tableBody.appendChild(row);
            
            // Add event listener to the edit button
            const editButton = row.querySelector('.btn-edit');
            editButton.addEventListener('click', function() {
                getOrderDetails(order.id);
            });
        });
    }

    // Get detailed order info for the modal
    function getOrderDetails(orderId) {
        fetch(`../logic/admin/get_order_details.php?id=${orderId}`)
            .then(response => response.json())
            .then(orderData => {
                openStatusModal(orderData);
            })
            .catch(error => {
                console.error('Error getting order details:', error);
                showNotification('Gagal memuat detail pesanan');
            });
    }

    // Modal handler
    function openStatusModal(orderData) {
        if (orderData) {
            document.getElementById('orderId').value = orderData.id;
            document.getElementById('customerName').value = orderData.nama_user;
            
            const orderDetails = `${orderData.nama_produk} (${orderData.jumlah}x)`;
            document.getElementById('orderDetails').value = orderDetails;
            document.getElementById('orderPrice').value = `Rp ${formatPrice(orderData.harga_total)}`;
            
            // Set current status in dropdown
            const statusSelect = document.getElementById('orderStatus');
            for (let i = 0; i < statusSelect.options.length; i++) {
                if (statusSelect.options[i].value === orderData.status) {
                    statusSelect.selectedIndex = i;
                    break;
                }
            }
            
            document.getElementById('statusNote').value = orderData.notes || '';

            modal.style.display = 'block';
        }
    }

    function closeModal() {
        modal.style.display = 'none';
        editForm.reset();
    }

    editForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const updatedData = {
            id: parseInt(document.getElementById('orderId').value),
            status: document.getElementById('orderStatus').value,
            notes: document.getElementById('statusNote').value || ''
        };
    
        console.log('Sending data:', updatedData);
    
        // Send data to server using fetch
        fetch('../logic/admin/update_order_status.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedData)
        })
        .then(response => {
            // Log the raw response for debugging
            return response.text().then(text => {
                console.log('Raw response:', text);
                try {
                    // Try to parse as JSON
                    return JSON.parse(text);
                } catch (e) {
                    console.error('Failed to parse response as JSON:', e);
                    throw new Error('Server returned invalid JSON: ' + text.substring(0, 100));
                }
            });
        })
        .then(result => {
            console.log('Parsed response:', result);
            if (result.success) {
                showNotification('Status pesanan berhasil diperbarui!');
                closeModal();
                loadOrders(); // Reload orders to see changes
            } else {
                showNotification('Gagal memperbarui status: ' + (result.message || 'unknown error'));
            }
        })
        .catch(error => {
            console.error('Error updating order status:', error);
            showNotification('Terjadi kesalahan koneksi. Detail: ' + error.message);
        });
    });

    function showNotification(message) {
        const existing = document.querySelector('.notification');
        if (existing) document.body.removeChild(existing);

        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('hide');
            setTimeout(() => {
                if (notification.parentNode) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    modalClose.addEventListener('click', closeModal);
    cancelButton.addEventListener('click', closeModal);
    window.addEventListener('click', function (e) {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Load orders when page loads
    loadOrders();
});