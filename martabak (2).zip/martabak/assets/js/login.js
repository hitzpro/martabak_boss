/**
 * Martabak No Debat - Login/Register Page JavaScript
 * This script handles form toggling, validation and password strength
 */
document.addEventListener('DOMContentLoaded', function() {
    // Form wrapper elements
    const loginFormWrapper = document.getElementById('loginFormWrapper');
    const registerFormWrapper = document.getElementById('registerFormWrapper');
    
    // Toggle buttons
    const showRegisterFormBtn = document.getElementById('showRegisterForm');
    const backToLoginBtn = document.getElementById('backToLogin');
    
    // Form elements
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    // Login form fields and errors
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const usernameError = document.getElementById('username-error');
    const passwordError = document.getElementById('password-error');
    
    // Register form fields and errors
    const emailInput = document.getElementById('email');
    const nameInput = document.getElementById('name');
    const regPasswordInput = document.getElementById('reg-password');
    const emailError = document.getElementById('email-error');
    const nameError = document.getElementById('name-error');
    const regPasswordError = document.getElementById('reg-password-error');
    
    // Password strength elements
    const passwordStrength = document.getElementById('password-strength');
    
    // ====== Form Toggle Functions ======
    
    // Show registration form, hide login form
    if (showRegisterFormBtn) {
        showRegisterFormBtn.addEventListener('click', function(e) {
            e.preventDefault();
            loginFormWrapper.classList.add('hidden');
            registerFormWrapper.classList.remove('hidden');
        });
    }
    
    // Show login form, hide registration form
    if (backToLoginBtn) {
        backToLoginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            registerFormWrapper.classList.add('hidden');
            loginFormWrapper.classList.remove('hidden');
        });
    }
    
    // ====== Login Form Validation ======
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            // Reset error messages
            usernameError.textContent = '';
            passwordError.textContent = '';
            
            let isValid = true;
            
            // Validate username
            if (!usernameInput.value.trim()) {
                usernameError.textContent = 'Username tidak boleh kosong';
                isValid = false;
            } else if (usernameInput.value.trim().length < 3) {
                usernameError.textContent = 'Username minimal 3 karakter';
                isValid = false;
            }
            
            // Validate password
            if (!passwordInput.value) {
                passwordError.textContent = 'Password tidak boleh kosong';
                isValid = false;
            } else if (passwordInput.value.length < 6) {
                passwordError.textContent = 'Password minimal 6 karakter';
                isValid = false;
            }
            
            // If validation fails, prevent form submission
            if (!isValid) {
                event.preventDefault();
            }
            
            // If validation passes, form will submit to process_login.php
            // PHP will need to handle server-side validation and authentication
        });
    }
    
    // ====== Registration Form Validation ======
    
    if (registerForm) {
        registerForm.addEventListener('submit', function(event) {
            // Reset error messages
            emailError.textContent = '';
            nameError.textContent = '';
            regPasswordError.textContent = '';
            
            let isValid = true;
            
            // Validate email
            if (!emailInput.value.trim()) {
                emailError.textContent = 'Email tidak boleh kosong';
                isValid = false;
            } else if (!isValidEmail(emailInput.value.trim())) {
                emailError.textContent = 'Format email tidak valid';
                isValid = false;
            }
            
            // Validate name
            if (!nameInput.value.trim()) {
                nameError.textContent = 'Nama tidak boleh kosong';
                isValid = false;
            } else if (nameInput.value.trim().length < 3) {
                nameError.textContent = 'Nama minimal 3 karakter';
                isValid = false;
            }
            
            // Validate password
            if (!regPasswordInput.value) {
                regPasswordError.textContent = 'Password tidak boleh kosong';
                isValid = false;
            } else if (regPasswordInput.value.length < 8) {
                regPasswordError.textContent = 'Password minimal 8 karakter';
                isValid = false;
            } else if (getPasswordStrength(regPasswordInput.value) === 'weak') {
                regPasswordError.textContent = 'Password terlalu lemah';
                isValid = false;
            }
            
            // If validation fails, prevent form submission
            if (!isValid) {
                event.preventDefault();
            }
            
            // If validation passes, form will submit to process_register.php
            // PHP will need to handle server-side validation and user creation
        });
    }
    
    // ====== Password Strength Checker ======
    
    if (regPasswordInput) {
        regPasswordInput.addEventListener('input', function() {
            const password = regPasswordInput.value;
            const strength = getPasswordStrength(password);
            
            // Update password strength indicator
            passwordStrength.className = 'mnd-password-strength';
            if (password.length > 0) {
                passwordStrength.classList.add(strength);
            }
            
            // Clear error message when typing
            regPasswordError.textContent = '';
        });
    }
    
    // Clear error messages when typing
    if (usernameInput) {
        usernameInput.addEventListener('input', function() {
            usernameError.textContent = '';
        });
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            passwordError.textContent = '';
        });
    }
    
    if (emailInput) {
        emailInput.addEventListener('input', function() {
            emailError.textContent = '';
        });
    }
    
    if (nameInput) {
        nameInput.addEventListener('input', function() {
            nameError.textContent = '';
        });
    }
    
    // ====== Helper Functions ======
    
    /**
     * Validates email format
     * @param {string} email - Email to validate
     * @return {boolean} - True if email is valid
     */
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    /**
     * Calculates password strength
     * @param {string} password - Password to check
     * @return {string} - 'weak', 'medium', or 'strong'
     */
    function getPasswordStrength(password) {
        // Check password length
        if (password.length < 8) {
            return 'weak';
        }
        
        let strength = 0;
        
        // Check for lowercase letters
        if (password.match(/[a-z]+/)) {
            strength += 1;
        }
        
        // Check for uppercase letters
        if (password.match(/[A-Z]+/)) {
            strength += 1;
        }
        
        // Check for numbers
        if (password.match(/[0-9]+/)) {
            strength += 1;
        }
        
        // Check for special characters
        if (password.match(/[^a-zA-Z0-9]+/)) {
            strength += 1;
        }
        
        // Return strength level
        if (strength < 3) {
            return 'weak';
        } else if (strength === 3) {
            return 'medium';
        } else {
            return 'strong';
        }
    }
});