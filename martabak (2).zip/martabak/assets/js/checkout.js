document.addEventListener("DOMContentLoaded", function () {
    const hargaAsli = parseFloat(document.getElementById("hargaAsli")?.value) || 0;
  
    const hargaJenis = {
      "Biasa": 0,
      "Red Velvet": 5000,
      "Black Forest": 10000,
    };
  
    const hargaVarian = {
      "Biasa": 0,
      "Tebel": 5000,
      "Lumer": 7000,
      "Tipis": 3000,
    };
  
    const PPN_PERSEN = 10;
    const ONGKIR = 8000;
  
    const jenisMartabak = document.getElementById("jenisMartabak");
    const varianMartabak = document.getElementById("varianMartabak");
    const jumlahPesan = document.getElementById("jumlahPesan");
    const catatan = document.getElementById("catatan");
  
    const summaryJenis = document.getElementById("summaryJenis");
    const summaryVarian = document.getElementById("summaryVarian");
    const summaryJumlah = document.getElementById("summaryJumlah");
    const summaryCatatan = document.getElementById("summaryCatatan");
    const summaryTotal = document.getElementById("summaryTotal");
  
    function formatRupiah(angka) {
      return "Rp. " + angka.toLocaleString("id-ID");
    }
  
    function updateSummary() {
      const jenis = jenisMartabak.value || "Biasa";
      const varian = varianMartabak.value || "Biasa";
      const jumlah = parseInt(jumlahPesan.value) || 1;
      const note = catatan.value || "-";
  
      const tambahanJenis = hargaJenis[jenis] || 0;
      const tambahanVarian = hargaVarian[varian] || 0;
  
      const hargaSatuan = hargaAsli + tambahanJenis + tambahanVarian;
      const subtotal = hargaSatuan * jumlah;
      const ppn = subtotal * (PPN_PERSEN / 100);
      const total = subtotal + ppn + ONGKIR;
  
      summaryJenis.innerText = jenis;
      summaryVarian.innerText = varian;
      summaryJumlah.innerText = jumlah;
      summaryCatatan.innerText = note;
      summaryTotal.innerText = formatRupiah(total);
  
      // Accordion detail harga
      document.getElementById("detailBase").innerText = formatRupiah(hargaAsli);
      document.getElementById("detailJenis").innerText = formatRupiah(tambahanJenis);
      document.getElementById("detailVarian").innerText = formatRupiah(tambahanVarian);
      document.getElementById("detailSubtotal").innerText = formatRupiah(subtotal);
      document.getElementById("detailPPN").innerText = formatRupiah(ppn);
      document.getElementById("detailOngkir").innerText = formatRupiah(ONGKIR);
      document.getElementById("detailTotal").innerText = formatRupiah(total);
    }
  
    // Event listener input
    jenisMartabak.addEventListener("change", updateSummary);
    varianMartabak.addEventListener("change", updateSummary);
    jumlahPesan.addEventListener("input", updateSummary);
    catatan.addEventListener("input", updateSummary);
  
    // Accordion toggle
    const accordionToggle = document.getElementById("accordionToggle");
    const accordionContent = document.getElementById("accordionContent");
  
    accordionToggle.addEventListener("click", function () {
      accordionContent.classList.toggle("active");
      accordionToggle.innerText = accordionContent.classList.contains("active")
        ? "Sembunyikan Detail Harga"
        : "Lihat Detail Harga";
    });
  
    // First render
    updateSummary();
  });
  

  document.addEventListener('DOMContentLoaded', function() {
    // Get the file input and the file name display element
    const uploadInput = document.getElementById('uploadBukti');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    
    // Add event listener for when a file is selected
    uploadInput.addEventListener('change', function() {
      // Check if a file was selected
      if (this.files && this.files.length > 0) {
        // Display the name of the selected file
        fileNameDisplay.textContent = this.files[0].name;
      } else {
        // If no file is selected, show the default text
        fileNameDisplay.textContent = 'Belum ada file dipilih';
      }
    });
  });