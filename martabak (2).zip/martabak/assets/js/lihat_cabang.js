// Handle iframe loading errors
document.addEventListener('DOMContentLoaded', function() {
    const iframes = document.querySelectorAll('.mnd-branch-map iframe');
    const placeholders = document.querySelectorAll('.mnd-map-placeholder');
    
    // Check if iframe loads correctly
    iframes.forEach((iframe, index) => {
        iframe.addEventListener('error', function() {
            // Show placeholder text if iframe fails to load
            if (placeholders[index]) {
                placeholders[index].style.display = 'block';
            }
        });
        
        // Hide placeholder text when iframe loads successfully
        iframe.addEventListener('load', function() {
            if (placeholders[index]) {
                placeholders[index].style.display = 'none';
            }
        });
    });
    
    // Mobile menu functionality can be added here if needed
});