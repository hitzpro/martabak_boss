document.addEventListener('DOMContentLoaded', function() {
    // Simple script to enhance the order history page
    const orderCards = document.querySelectorAll('.order-card');
    
    // Add hover effect interaction
    orderCards.forEach(card => {
        card.addEventListener('mouseover', function() {
            this.style.backgroundColor = '#e0e0e0';
        });
        
        card.addEventListener('mouseout', function() {
            this.style.backgroundColor = '#e9e9e9';
        });
    });
    
    // Handle pagination buttons
    const paginationBtns = document.querySelectorAll('.pagination-btn');
    
    paginationBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // In a real implementation, this would load the next/previous page of orders
            // PHP: Handle pagination logic
            // const page = this.dataset.page;
            // window.location.href = `riwayat_pesanan.php?page=${page}`;
            
            // For demo purposes only
            console.log(`Navigating to ${this.textContent} page`);
        });
    });
});