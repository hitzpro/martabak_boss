// SIDEBAR KODE
document.addEventListener('DOMContentLoaded', function() {
    // Select all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    
    // Function to set active menu item
    function setActiveMenu(menuId) {
        // Remove active class from all menu items
        menuItems.forEach(item => {
            item.classList.remove('active');
        });
        
        // Add active class to selected menu item
        const selectedMenu = document.querySelector(`[data-menu="${menuId}"]`);
        if (selectedMenu) {
            selectedMenu.classList.add('active');
        }
    }
    
    // Add click event listeners to menu items
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            const menuId = this.getAttribute('data-menu');
            
            // Handle logout separately
            if (menuId === 'logout') {
                e.preventDefault();  // Prevent navigating for logout
                if (confirm('Apakah Anda yakin ingin keluar?')) {
                    alert('Logout berhasil!');
                    window.location.href = '../logic/logout.php';  // Redirect to logout page
                }
                return;
            }
            
            // For other menu items, allow normal navigation
            setActiveMenu(menuId);
        });
    });
    

});


document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('editModal');
    const closeModalBtn = document.querySelector('.close');
    const cancelBtn = document.querySelector('.btn-cancel');
    const editButtons = document.querySelectorAll('.edit-btn');

    const productIdInput = document.getElementById('productId');
    const nameInput = document.getElementById('productName');
    const descInput = document.getElementById('productDescription');
    const stockInput = document.getElementById('productStock');
    const priceInput = document.getElementById('productPrice');
    const imageInput = document.getElementById('productImage');

    // Buka modal dan ambil data produk berdasarkan ID
    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const productId = this.dataset.id;

            fetch(`../logic/admin/get_produk.php?id=${productId}`)

            .then(response => response.text()) // Ubah sementara ke text dulu
            .then(text => {
                console.log('RESPON MENTAH:', text);
                const data = JSON.parse(text); // manual parse
                if (data.error) {
                    alert(data.error);
                    return;
                }
        
                // Isi form
                productIdInput.value = data.id;
                nameInput.value = data.nama;
                descInput.value = data.deskripsi;
                stockInput.value = data.stok;
                priceInput.value = data.harga;
        
                modal.style.display = 'block';
            })
            .catch(error => {
                console.error('Gagal mengambil data:', error);
            });
        
        });
    });

    // Tutup modal
    function closeModal() {
        modal.style.display = 'none';
    }

    closeModalBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    window.addEventListener('click', function (event) {
        if (event.target === modal) {
            closeModal();
        }
    });

    document.getElementById('editProductForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Menghindari reload otomatis
    
        const formData = new FormData(this);
        const productId = document.getElementById('productId').value;
    
        // Menampilkan alert konfirmasi
        const confirmUpdate = confirm('Apakah Anda yakin ingin mengupdate produk ini?');
        if (confirmUpdate) {
            // Jika user mengonfirmasi, kirim data update ke server
            fetch(`../logic/admin/update_produk.php?id=${productId}`, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                // First check if the response is ok
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                
                // Try to parse as JSON
                return response.text().then(text => {
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error("Failed to parse JSON response:", text);
                        throw new Error("Server returned invalid JSON. Check server logs.");
                    }
                });
            })
            .then(data => {
                if (data.success) {
                    alert('Produk berhasil diupdate!');
                    location.reload(); // Refresh halaman untuk melihat perubahan
                } else {
                    alert(`Gagal update produk: ${data.message || 'Unknown error'}`);
                }
            })
            .catch(err => {
                console.error("Error details:", err);
                alert('Terjadi kesalahan saat memperbarui produk. Lihat console untuk detail.');
            });
        }
    });
});
