// profile.js

document.addEventListener('DOMContentLoaded', function() {
    // Referensi ke elemen-elemen
    const resetBtn = document.getElementById('resetBtn');
    const saveBtn = document.getElementById('saveBtn');
    const menuToggle = document.getElementById('menuToggle');
    
    // Form fields
    const nameInput = document.getElementById('nama');
    const emailInput = document.getElementById('email');
    const ageInput = document.getElementById('umur');
    const addressInput = document.getElementById('alamat');
    
    // Simpan nilai awal untuk reset
    const initialValues = {
        name: nameInput.value,
        email: emailInput.value,
        age: ageInput.value,
        address: addressInput.value
    };
    
    // Handler tombol reset
    resetBtn.addEventListener('click', function() {
        // Konfirmasi reset
        if (confirm('Apakah Anda yakin ingin menghapus semua data perubahan?')) {
            nameInput.value = initialValues.name;
            emailInput.value = initialValues.email;
            ageInput.value = initialValues.age;
            addressInput.value = initialValues.address;
            
            // Tampilkan notifikasi
            showNotification('Data berhasil direset');
        }
    });
    
    // Handler tombol simpan
    saveBtn.addEventListener('click', function() {
        // Validasi dasar
        if (!nameInput.value.trim()) {
            alert('Nama tidak boleh kosong');
            nameInput.focus();
            return;
        }
        
        if (!emailInput.value.trim()) {
            alert('Email tidak boleh kosong');
            emailInput.focus();
            return;
        }
        
        // Simulasi pengiriman data
        // Di sini seharusnya ada kode AJAX untuk mengirim data ke server PHP
        
        // Contoh data yang akan dikirim:
        const formData = {
            name: nameInput.value,
            email: emailInput.value,
            age: ageInput.value,
            address: addressInput.value
        };
        
        console.log('Data yang akan dikirim:', formData);
        
        // Pada implementasi sebenarnya:
        /*
        fetch('update_profile.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('Data berhasil disimpan');
                
                // Update nilai awal setelah berhasil disimpan
                initialValues.name = nameInput.value;
                initialValues.email = emailInput.value;
                initialValues.age = ageInput.value;
                initialValues.address = addressInput.value;
            } else {
                showNotification('Gagal menyimpan data', 'error');
            }
        })
        .catch(error => {
            showNotification('Terjadi kesalahan', 'error');
        });
        */
        
        // Simulasi berhasil
        showNotification('Data berhasil disimpan');
    });
    
    // Toggle menu mobile
    menuToggle.addEventListener('click', function() {
        // Logika untuk menampilkan/menyembunyikan menu pada tampilan mobile
        // Pada implementasi sebenarnya, tambahkan kode untuk menampilkan menu dropdown
        console.log('Toggle menu');
    });
    
    // Fungsi untuk menampilkan notifikasi
    function showNotification(message, type = 'success') {
        // Buat elemen notifikasi
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Tambahkan ke body
        document.body.appendChild(notification);
        
        // Styling notifikasi
        Object.assign(notification.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '12px 20px',
            borderRadius: '4px',
            zIndex: '1000',
            fontSize: '14px',
            boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
            transition: 'all 0.3s ease'
        });
        
        // Style berdasarkan tipe
        if (type === 'success') {
            notification.style.backgroundColor = '#e8f5e9';
            notification.style.color = '#2e7d32';
            notification.style.border = '1px solid #a5d6a7';
        } else {
            notification.style.backgroundColor = '#ffebee';
            notification.style.color = '#c62828';
            notification.style.border = '1px solid #ef9a9a';
        }
        
        // Hapus notifikasi setelah beberapa detik
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
        
        // Animasi masuk
        setTimeout(() => {
            notification.style.opacity = '1';
        }, 10);
    }
});