<?php
include('../../config/db.php');
$limit = 5;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Query untuk mengambil data transaksi dan informasi produk terkait
$sql = "SELECT t.*, p.nama_produk, p.jumlah 
        FROM transaksi t
        LEFT JOIN pemesanan p ON t.user_id = p.user_id AND t.total_harga = p.harga_total
        ORDER BY t.tanggal_pesan DESC 
        LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// Menghitung total data untuk pagination
$total_result = $conn->query("SELECT COUNT(*) AS total FROM transaksi");
$total_row = $total_result->fetch_assoc();
$total_data = $total_row['total'];

// Menghitung jumlah halaman
$total_pages = ceil($total_data / $limit);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan - Martabak No Debat</title>
    <link rel="stylesheet" href="../../assets/css/riwayat_pemesanan.css">
    <link rel="icon" href="../../assets/icon/logo.png" type="image/png">

</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Martabak No Debat</div>
            <nav>
                <ul>
                    <li><a href="index.php">Beranda</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="history-container">
            <h1>Riwayat Pesanan</h1>
            
            <div class="order-list">
                <!-- Menampilkan pesanan dari database -->
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <div class="order-card">
                            <div class="order-info">
                                <div class="order-name">
                                    <?php echo !empty($row['nama_produk']) ? htmlspecialchars($row['nama_produk']) : 'Martabak Manis'; ?>
                                </div>
                                <div class="order-quantity">
                                    <?php echo !empty($row['jumlah']) ? $row['jumlah'] : '1'; ?>
                                </div>
                                <div class="order-date"><?php echo date('d F Y', strtotime($row['tanggal_pesan'])); ?></div>
                                <div class="order-price">Rp. <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></div>
                                <div class="order-status <?php echo $row['status'] == 'berhasil' ? 'selesai' : 'gagal'; ?>">
                                    <?php echo ucfirst($row['status']); ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>Belum ada pesanan</p>
                <?php endif; ?>
            </div>
            
            <div class="pagination">
                <!-- Tombol Sebelumnya -->
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>" class="pagination-btn">Sebelumnya</a>
                <?php endif; ?>

                <!-- Tombol Selanjutnya -->
                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>" class="pagination-btn">Selanjutnya</a>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <script src="../../assets/js/riwayat_pemesanan.js"></script>
</body>
</html>

<?php
// Menutup koneksi
$conn->close();
?>