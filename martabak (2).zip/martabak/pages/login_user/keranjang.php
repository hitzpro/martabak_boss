<?php
session_start();
// Periksa apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit();
}
$user_id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Martabak No Debat - Keranjang</title>
    <link rel="stylesheet" href="../../assets/css/keranjang.css">
    <link rel="icon" href="../../assets/icon/logo.png" type="image/png">

</head>
<body>
    <header>
        <div class="container">
            <div class="logo">LOGO</div>
            <nav>
                <ul>
                    <li><a href="index.php">Beranda</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            <h1>Keranjang</h1>
            
            <div class="cart-container">
                <div class="cart-items" id="cartItems">
                    <!-- Cart items will be populated dynamically -->
                    <div class="cart-empty" style="display: none;">
                        <p>Belum ada produk di keranjang.</p>
                        <a href="index.php" class="btn">Belanja Sekarang</a>
                    </div>
                </div>

                <div class="detail-container" id="detailContainer">
                    <h2>DETAIL</h2>
                    <p>Hover pada item untuk melihat detail produk</p>
                </div>
            </div>

            <div class="pagination" id="cartPagination">
                <button class="btn btn-prev" id="prevBtn">Sebelumnya</button>
                <button class="btn btn-next" id="nextBtn">Selanjutnya</button>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <script src="../../assets/js/keranjang.js"></script>
</body>
</html>