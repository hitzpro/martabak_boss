<?php
session_start();
include '../../config/db.php';  // Pastikan file koneksi.php sudah ada
// Periksa apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['id'];  // Mendapatkan user_id dari session

// Query untuk mengambil data pesanan berdasarkan user_id
$query = "SELECT * FROM pemesanan WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $query);

// Cek jika query berhasil
if (!$result) {
    die("Query gagal: " . mysqli_error($conn));
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Pesanan - Martabak No Debat</title>
    <link rel="stylesheet" href="../../assets/css/lihat_status_pesanan.css">
    <link rel="icon" href="../../assets/icon/logo.png" type="image/png">

</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Martabak No Debat</div>
            <nav>
                <ul>
                    <li><a href="index.php">Beranda</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="status-container">
            <h1>Status Pesanan</h1>
            
            <div class="status-content">
                <div class="status-table">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Jumlah</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- PHP: Tampilkan data pesanan dari database -->
                            <?php
                            $no = 1;  // Nomor urut
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_array($result)) {
                                    // Menentukan kelas CSS berdasarkan status
                                    $status_class = "";
                                    switch ($row['status']) {
                                        case 'menunggu konfirmasi':
                                            $status_class = "menunggu-konfirmasi";
                                            break;
                                        case 'sedang diproses':
                                            $status_class = "sedang-diproses";
                                            break;
                                        case 'sedang dikirim':
                                            $status_class = "sedang-dikirim";
                                            break;
                                        case 'dibatalkan':
                                            $status_class = "dibatalkan";
                                            break;
                                    }
                                    // Ambil nama produk dari tabel produk (optional)
                                    $produk_id = $row['produk_id'];
                                    $produk_query = "SELECT nama FROM produk WHERE id = '$produk_id'";
                                    $produk_result = mysqli_query($conn, $produk_query);
                                    $produk = mysqli_fetch_assoc($produk_result);

                                    echo '<tr>';
                                    echo '<td>' . $no++ . '</td>';
                                    echo '<td>' . $produk['nama'] . '</td>';
                                    echo '<td>' . $row['jumlah'] . '</td>';
                                    echo '<td><span class="status ' . $status_class . '">' . ucfirst($row['status']) . '</span></td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="4" class="no-orders">Belum ada pesanan</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="status-detail">
                    <h2>DETAIL</h2>
                    <p id="order-status-message">Pilih pesanan untuk melihat status.</p>
                </div>

            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <script src="../../assets/js/lihat_status_pemesanan.js"></script>
</body>
</html>
