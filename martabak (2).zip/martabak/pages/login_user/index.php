<?php
session_start();
include '../../config/db.php';  // Sesuaikan path dengan file db.php kamu

// Pastikan user sudah login
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id'];

    // Ambil data user berdasarkan id
    $query = "SELECT username, foto FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Jika user ditemukan
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $user_name = $user['username'];
        $user_photo = !empty($user['foto']) ? '../../assets/img/foto_profile/' . $user['foto'] : '';
    } else {
        // Jika user tidak ditemukan, redirect atau beri pesan error
        echo "User tidak ditemukan!";
        exit;
    }

    $stmt->close();
} else {
    // Jika user belum login, arahkan ke halaman login
    header("Location: login.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Martabak No Debat - Pilihan Pasti Untuk Pecinta Martabak</title>
    <link rel="stylesheet" href="../../assets/css/index.css">
    <link rel="icon" href="../../assets/icon/logo.png" type="image/png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Header Section -->
    <header class="mnd-header">
        <div class="mnd-logo">
            <h1>MARTABAK NO DEBAT</h1>
        </div>
        <nav class="simple-navbar">            
            <div class="navbar-menu">
                <a href="#">Beranda</a>
                <a href="lihat_cabang.php">Lihat Cabang</a>
            </div>
            
            <div class="navbar-profile">
                <a href="profil.php" class="link-nav">
                    <div class="profile-icon">
                        <!-- Foto profil -->
                        <?php if ($user_photo): ?>
                            <img src="<?php echo $user_photo; ?>" alt="Foto Profil" width="24" height="24">
                        <?php else: ?>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                                <path fill="none" d="M0 0h24v24H0z"/>
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" fill="#333"/>
                            </svg>
                        <?php endif; ?>
                    </div>
                    <!-- Nama user -->
                    <span class="profile-name"><?php echo $user_name; ?></span>
                </a>
            </div>

        </nav>
    </header>

    <!-- Hero Section -->
    <section class="mnd-hero">
        <div class="mnd-hero-content">
            <h2>SELAMAT DATANG DI</h2>
            <h1>MARTABAK NO DEBAT</h1>
            <p>Kami Hadir Dengan Resep Terbaik Dan Topping Pilihan, Disiapkan Dengan Penuh Cinta Dari Dapur Ke Tanganmu. Martabak No Debat, Pilihan Pasti Untuk Pecinta Martabak Sejati.</p>
            <a href="#products" class="mnd-scroll-btn">
                <i class="fas fa-chevron-down"></i>
            </a>
        </div>
        <div class="mnd-hero-overlay"></div>
    </section>

    <!-- Running Text -->
    <div class="mnd-running-text">
        <div class="mnd-running-text-content">
            <p>Teks Berjalan Akan ada disini - Promo Spesial Bulan Ini - Beli 2 Martabak Gratis 1 - Promo Spesial Hari Ini - </p>
        </div>
    </div>

    <!-- Search Section -->
    <section class="mnd-search">
        <div class="mnd-container">
            <h2>Cari Martabak Kesukaan Anda Disini</h2>
            <div class="mnd-search-box">
                <input type="text" placeholder="Ketik Sesuatu Disini" class="mnd-search-input">
                <button class="mnd-search-btn">Cari</button>
            </div>
            <a href="#" class="mnd-see-all">Lihat selengkapnya</a>
        </div>
    </section>

    <!-- Products Carousel -->
    <section id="products" class="mnd-products">
        <div class="mnd-container">
            <div class="mnd-carousel-container">
                <button class="mnd-carousel-btn mnd-prev-btn" id="prevBtn">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <div class="mnd-carousel-wrapper">
                    <div class="mnd-carousel" id="productCarousel">
                        <!-- Produk akan dimuat oleh JS -->
                    </div>
                </div>
                <button class="mnd-carousel-btn mnd-next-btn" id="nextBtn">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
            <div class="mnd-carousel-pagination" id="carouselPagination"></div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="mnd-faq">
        <div class="mnd-container">
            <h2>FAQ</h2>
            <div class="mnd-faq-content">
                <div class="mnd-faq-left">
                    <div class="mnd-accordion">
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Gimana cara memesan di website ini ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Anda dapat memesan dengan memilih menu martabak yang diinginkan, klik tombol "Beli Sekarang", lalu ikuti proses checkout hingga selesai.</p>
                            </div>
                        </div>
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Bisa Bayar COD ga ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Ya, kami menerima pembayaran COD (Cash On Delivery) untuk pesanan dalam area pengiriman tertentu.</p>
                            </div>
                        </div>
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Cabangnya ada dimana aja nih ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Cabang Martabak No Debat tersebar di beberapa lokasi. Silakan kunjungi halaman "Lihat Cabang" untuk informasi lokasi terdekat dengan Anda.</p>
                            </div>
                        </div>
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Cara Bayarnya gimana ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Kami menerima berbagai metode pembayaran termasuk transfer bank, e-wallet (OVO, GoPay, Dana), kartu kredit, dan COD untuk area tertentu.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mnd-faq-right">
                    <img src="../../assets/img/ilustrasi/faq.png" alt="FAQ Illustration">
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="mnd-footer">
        <div class="mnd-container">
            <p>2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <script src="../../assets/js/index.js"></script>
</body>
</html>