<?php
session_start();
include '../../config/db.php';  // Sesuaikan path dengan file db.php kamu

// Pastikan user sudah login
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id'];

    // Ambil data user berdasarkan id
    $query = "SELECT username, foto FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Jika user ditemukan
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $user_name = $user['username'];
        $user_photo = !empty($user['foto']) ? '../../assets/img/foto_profile/' . $user['foto'] : '';
    } else {
        // Jika user tidak ditemukan, redirect atau beri pesan error
        echo "User tidak ditemukan!";
        exit;
    }

    $stmt->close();
} else {
    // Jika user belum login, arahkan ke halaman login
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Martabak No Debat | Cabang</title>
    <link rel="stylesheet" href="../../assets/css/lihat_cabang.css">
    <link rel="icon" href="../../assets/icon/logo.png" type="image/png">

</head>
<body>
    <!-- Header Section -->
    <header class="mnd-header">
        <div class="mnd-logo">
            <h1>MARTABAK NO DEBAT</h1>
        </div>
        <nav class="simple-navbar">            
            <div class="navbar-menu">
                <a href="index.php">Beranda</a>
                <a href="lihat_cabang.php">Lihat Cabang</a>
            </div>
            
            <div class="navbar-profile">
                <a href="profil.php" class="link-nav">
                    <div class="profile-icon">
                        <!-- Foto profil -->
                        <?php if ($user_photo): ?>
                            <img src="<?php echo $user_photo; ?>" alt="Foto Profil" width="24" height="24">
                        <?php else: ?>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                                <path fill="none" d="M0 0h24v24H0z"/>
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" fill="#333"/>
                            </svg>
                        <?php endif; ?>
                    </div>
                    <!-- Nama user -->
                    <span class="profile-name"><?php echo $user_name; ?></span>
                </a>
            </div>

        </nav>
    </header>

    <main>
        <section class="mnd-hero">
            <div class="mnd-container">
                <div class="mnd-hero-content">
                    <h2 class="mnd-subtitle">CABANG TEMPAT</h2>
                    <h1 class="mnd-title">MARTABAK NO DEBAT</h1>
                </div>
            </div>
        </section>

        <section class="mnd-branch">
            <div class="mnd-container">
                <div class="mnd-branch-content">
                    <div class="mnd-branch-info">
                        <h2 class="mnd-branch-title">CABANG 1</h2>
                        <p class="mnd-branch-desc">
                            Lorem Ipsum Is Simply Dummy Text Of The Printing And Typesetting Industry. 
                            Lorem Ipsum Has Been The Industry's Standard Dummy Text Ever Since The 1500s, 
                            When An Unknown Printer Took A Galley Of Type And Scrambled It To Make A Type 
                            Specimen Book.
                        </p>
                    </div>
                    <div class="mnd-branch-map">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15894.123456789!2d106.9636695!3d-6.2936589!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2z!5e0!3m2!1sid!2sid!4v1616161616161"
                        width="100%"
                        height="100%"
                        style="border:0;"
                        allowfullscreen=""
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade">
                    </iframe>

                        <p class="mnd-map-placeholder">IFRAME DARI GMAPS</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="mnd-branch mnd-branch-reverse">
            <div class="mnd-container">
                <div class="mnd-branch-content">
                    <div class="mnd-branch-map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.6664270983986!2d106.81612231537937!3d-6.175785662398261!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5d2e764b12d%3A0x3d2ad6e1e0e9bcc8!2sIstiqlal%20Mosque!5e0!3m2!1sid!2sid!4v1650169177271!5m2!1sid!2sid" 
                               width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" 
                               referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <p class="mnd-map-placeholder">IFRAME DARI GMAPS</p>
                    </div>
                    <div class="mnd-branch-info">
                        <h2 class="mnd-branch-title">CABANG 2</h2>
                        <p class="mnd-branch-desc">
                            Lorem Ipsum Is Simply Dummy Text Of The Printing And Typesetting Industry. 
                            Lorem Ipsum Has Been The Industry's Standard Dummy Text Ever Since The 1500s, 
                            When An Unknown Printer Took A Galley Of Type And Scrambled It To Make A Type 
                            Specimen Book.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="mnd-footer">
        <div class="mnd-container">
            <p class="mnd-copyright">2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <script src="../../assets/js/lihat_cabang.js"></script>
</body>
</html>