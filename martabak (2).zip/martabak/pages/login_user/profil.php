<?php
session_start();
include '../../config/db.php'; // Database connection
if (!isset($_SESSION['id'])) {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location.href='../login.php';</script>";
    exit;
}

$user_id = $_SESSION['id'];

// Get user data from database
$query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$user = mysqli_fetch_assoc($query);

// User data to display
$user_name    = $user['username'];
$user_email   = $user['email'];
$user_age     = $user['umur'];
$user_address = $user['alamat_lengkap'];
$user_photo   = !empty($user['foto']) ? '../../assets/img/foto_profile/' . $user['foto'] : ''; 

// Handle photo upload
if (isset($_POST['upload'])) {
    // Check if file was uploaded without errors
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $allowed_extensions = array("jpg", "jpeg", "png", "gif");
        $file_extension = pathinfo($_FILES["photo"]["name"], PATHINFO_EXTENSION);
        
        // Check file extension
        if (in_array(strtolower($file_extension), $allowed_extensions)) {
            // Create uploads directory if it doesn't exist
            $upload_dir = '../../assets/img/foto_profile/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Create file name based on user ID and username
            $new_file_name = $user_id . "_" . $user_name . "." . $file_extension;
            $upload_path = $upload_dir . $new_file_name;
            
            // Move uploaded file to destination
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $upload_path)) {
                // Update database with the new photo path
                $update_sql = "UPDATE users SET foto = '$new_file_name' WHERE id = '$user_id'";
                if (mysqli_query($conn, $update_sql)) {
                    echo "<script>alert('Foto profil berhasil diupload!'); window.location.href='profil.php';</script>";
                    exit;
                } else {
                    echo "<script>alert('Terjadi kesalahan saat mengupdate database.'); window.history.back();</script>";
                }
            } else {
                echo "<script>alert('Terjadi kesalahan saat mengupload file.'); window.history.back();</script>";
            }
        } else {
            echo "<script>alert('Hanya file JPG, JPEG, PNG, dan GIF yang diperbolehkan.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Silakan pilih file untuk diupload.'); window.history.back();</script>";
    }
}

// Handle profile update
if (isset($_POST['save'])) {
    $nama   = mysqli_real_escape_string($conn, $_POST['nama']);
    $email  = mysqli_real_escape_string($conn, $_POST['email']);
    $umur   = mysqli_real_escape_string($conn, $_POST['umur']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);

    $update = mysqli_query($conn, "UPDATE users SET 
        username = '$nama',
        email = '$email',
        umur = '$umur',
        alamat_lengkap = '$alamat'
        WHERE id = '$user_id'
    ");

    if ($update) {
        echo "<script>alert('Profil berhasil diperbarui!'); window.location.href='profil.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui profil!'); window.history.back();</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link rel="stylesheet" href="../../assets/css/profil.css">
    <link rel="icon" href="../../assets/icon/logo.png" type="image/png">

    <style>
        .profile-image {
            width: 150px;
            height: 150px;
            margin-right: 20px;
            overflow: hidden;
            border-radius: 50%;
            border: 3px solid #ccc;
        }
        .profile-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .profile-placeholder {
            width: 100%;
            height: 100%;
            background-color: #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            color: #999;
        }
        .photo-upload-form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Martabak No Debat</div>
            <nav>
                <ul>
                    <li><a href="index.php">Beranda</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container">
        <div class="profile-header">
            <div class="profile-image">
                <?php if(isset($user_photo) && !empty($user_photo)): ?>
                    <img src="<?php echo $user_photo; ?>" alt="Foto Profil">
                <?php else: ?>
                    <div class="profile-placeholder"></div>
                <?php endif; ?>
            </div>
            
            <div class="profile-info">
                <h2 class="profile-name"><?php echo $user_name; ?></h2>
                <p class="profile-id">ID: <?php echo $user_id; ?></p>
            </div>
        </div>

        <!-- Photo Upload Form -->
        <form class="photo-upload-form" method="POST" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label for="photo">Pilih Foto Profil:</label>
                <input type="file" name="photo" id="photo" accept="image/*" required>
            </div>
            <button type="submit" name="upload" class="btn btn-primary">Upload Foto</button>
        </form>

        <!-- Profile Update Form -->
        <form method="POST" action="">
            <div class="profile-content">
                <div class="profile-form">
                    <div class="form-group">
                        <label for="nama">Nama akun</label>
                        <input type="text" id="nama" name="nama" value="<?php echo $user_name; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo $user_email; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="umur">Umur</label>
                        <input type="number" id="umur" name="umur" value="<?php echo $user_age; ?>">
                    </div>

                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <textarea id="alamat" name="alamat"><?php echo $user_address; ?></textarea>
                    </div>

                    <div class="form-actions">
                        <button class="btn btn-secondary" type="reset">Hapus Semua</button>
                        <button class="btn btn-primary" type="submit" name="save">Simpan</button>
                    </div>
                </div>
            </div>
        </form>

        <div class="profile-links">
            <a href="keranjang.php" class="action-link">Lihat Keranjang</a>
            <a href="lihat_status_pesanan.php" class="action-link">Lihat Status Pesanan</a>
            <a href="riwayat_pemesanan.php" class="action-link">Riwayat Transaksi</a>
            <a href="#" class="action-link logout">
                Logout 
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
            </a>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <script src="../../assets/js/profil.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const logoutLink = document.querySelector(".logout");

            logoutLink.addEventListener("click", function (e) {
                e.preventDefault(); // Prevent default link behavior
                const konfirmasi = confirm("Yakin ingin logout?");
                if (konfirmasi) {
                    window.location.href = "../../logic/process_logout.php";
                }
            });
        });
    </script>
</body>
</html>