<?php
session_start();
include '../../config/db.php';  // Pastikan file koneksi.php sudah ada

// Ambil id produk dari URL
$id_produk = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Ambil data produk dari database
$sql = "SELECT * FROM produk WHERE id = $id_produk";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $produk = $result->fetch_assoc();
} else {
  die("Produk tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Checkout - Martabak No Debat</title>
  <link rel="stylesheet" href="../../assets/css/checkout.css" />
  <link rel="icon" href="../../assets/icon/logo.png" type="image/png">

</head>
<body>
  <header>
    <div class="container">
      <div class="logo">Martabak No Debat</div>
      <nav>
        <ul>
          <li><a href="index.php">Beranda</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main class="container">
    <div class="checkout-container">
      <div class="product-details">
        <div class="product-image">
          <img src="<?= '../../assets/img/produk/' . htmlspecialchars($produk['gambar']) ?>" alt="<?= htmlspecialchars($produk['nama']) ?>" id="productImage" />
        </div>
        <div class="product-info">
          <h1 id="productTitle"><?= htmlspecialchars($produk['nama']) ?></h1>
          <p id="productDescription"><?= nl2br(htmlspecialchars($produk['deskripsi'])) ?></p>

          <form id="orderForm" action="../../logic/public/checkout.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <!-- Simpan harga asli dari database di elemen hidden -->
                <input type="hidden" id="hargaAsli" value="<?= $produk['harga'] ?>">
                <input type="hidden" name="produk_id" value="<?= $produk['id'] ?>">



              <label for="jenisMartabak">Jenis Martabak</label>
              <select id="jenisMartabak" name="jenisMartabak" required>
                <option value="" disabled selected>--Pilih Jenis Martabak--</option>
                <option value="Biasa">Biasa</option>
                <option value="Red Velvet">Red Velvet</option>
                <option value="Black Forest">Black Forest</option>
              </select>
            </div>

            <div class="form-group">
              <label for="varianMartabak">Varian</label>
              <select id="varianMartabak" name="varianMartabak" required>
                <option value="" disabled selected>--Pilih Varian Martabak--</option>
                <option value="Biasa">Biasa</option>
                <option value="Tebel">Tebel</option>
                <option value="Lumer">Lumer</option>
                <option value="Tipis">Tipis</option>
              </select>
            </div>

            <div class="form-group">
              <label for="jumlahPesan">Jumlah Pesan</label>
              <input type="number" id="jumlahPesan" name="jumlahPesan" min="1" value="1" required />
            </div>

            <div class="form-group">
              <label for="uploadBukti">Upload Bukti Pembayaran</label>
              <div class="upload-container">
                <input type="file" id="uploadBukti" name="uploadBukti" accept="image/*" />
                <label for="uploadBukti" class="upload-button">Pilih File</label>
                <span id="fileNameDisplay">Belum ada file dipilih</span>
              </div>
            </div>

            <div class="form-group">
              <label for="catatan">Catatan</label>
              <textarea id="catatan" name="catatan" placeholder="Tulis catatan tambahan di sini"></textarea>
            </div>
        </div>
    </div>

    <div class="order-summary">
        <h2>Ringkasan Pesanan</h2>
        <div class="summary-item">
          <span>Jenis Martabak:</span>
          <span id="summaryJenis">-</span>
        </div>
        <div class="summary-item">
          <span>Varian:</span>
          <span id="summaryVarian">-</span>
        </div>
        <div class="summary-item">
          <span>Jumlah Pesan:</span>
          <span id="summaryJumlah">1</span>
        </div>
        <div class="summary-item">
          <span>Catatan:</span>
          <span id="summaryCatatan">-</span>
        </div>
        <div class="divider"></div>
        <div class="summary-item total">
          <span>Total:</span>
          <span id="summaryTotal">Rp. <?= number_format($produk['harga'], 0, ',', '.') ?></span>
        </div>
        
        
        
        <!-- Tombol submit -->
        <button type="submit" id="pesanSekarang" class="order-button">Pesan Sekarang</button>
    </form>
    
    <div class="accordion">
        <button class="accordion-btn" id="accordionToggle">Lihat Detail Harga</button>
        <div class="accordion-content" id="accordionContent">
            <p>Harga Dasar: <span id="detailBase">Rp. 0</span></p>
            <p>Tambah Jenis: <span id="detailJenis">Rp. 0</span></p>
            <p>Tambah Varian: <span id="detailVarian">Rp. 0</span></p>
            <p>Subtotal: <span id="detailSubtotal">Rp. 0</span></p>
            <p>PPN (10%): <span id="detailPPN">Rp. 0</span></p>
            <p>Ongkir: <span id="detailOngkir">Rp. 8.000</span></p>
            <hr>
            <p><strong>Total: <span id="detailTotal">Rp. 0</span></strong></p>
        </div>
    </div>
        <div class="payment-info">
          <div class="qr-code">
            <img src="../../assets/img/ilustrasi/qris.png" alt="QR Code Pembayaran" />
          </div>
          <p class="payment-note">**Pembayaran hanya bisa melalui QRIS.</p>
        </div>
      </div>
    </div>
  </main>

  <footer>
    <div class="container">
      <p>&copy; 2025 Martabak No Debat</p>
    </div>
  </footer>

  <script src="../../assets/js/checkout.js"></script>
</body>
</html>
