<?php
session_start();
include '../config/db.php'; // Sesuaikan path ke database

// Cek apakah admin sudah login
if (!isset($_SESSION['id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$admin_id = $_SESSION['id'];

// Ambil data admin
$query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$admin_id' AND role = 'admin'");
$admin = mysqli_fetch_assoc($query);

$admin_name = $admin['username'];
$admin_photo = !empty($admin['foto']) ? '../../assets/img/foto_profile/' . $admin['foto'] : 'https://via.placeholder.com/150';

// Proses upload foto jika ada
if (isset($_POST['upload_photo'])) {
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['photo']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            $upload_dir = '../../assets/img/foto_profile/';
            
            // Create directory if not exists
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $new_filename = $admin_id . "_" . $admin_name . "." . $file_extension;
            $target_file = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                // Update database
                $update_query = mysqli_query($conn, "UPDATE users SET foto = '$new_filename' WHERE id = '$admin_id'");
                
                if ($update_query) {
                    // Refresh halaman
                    echo "<script>
                        alert('Foto profil berhasil diupload!');
                        window.location.href = window.location.href;
                    </script>";
                    exit;
                } else {
                    $error_message = "Gagal update database: " . mysqli_error($conn);
                }
            } else {
                $error_message = "Gagal upload file!";
            }
        } else {
            $error_message = "Tipe file tidak diizinkan. Gunakan JPG, PNG, atau GIF.";
        }
    } else {
        $error_message = "Silakan pilih file foto!";
    }
}
?>

<!-- Tombol Toggle Sidebar -->
<button id="toggleSidebar" class="toggle-btn">☰</button>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div class="profile">
        <div class="profile-img">
            <div class="profile-photo-container">
                <img src="<?php echo $admin_photo; ?>" alt="Admin Profile">
                <div class="edit-photo-icon" id="editPhotoBtn">
                    <i class="fas fa-camera"></i>
                    <span>Edit</span>
                </div>
            </div>
        </div>
        <div class="profile-info">
            <h3><?php echo $admin_name; ?></h3>
            <p>ID: <?php echo $admin_id; ?></p>
        </div>
    </div>

    <nav class="sidebar-menu">
        <ul>
            <li><a href="dashboard.php" class="menu-item" data-menu="dashboard"><span class="icon">🏠</span><span class="menu-text">Dashboard</span></a></li>
            <li><a href="atur_produk.php" class="menu-item" data-menu="stock"><span class="icon">📦</span><span class="menu-text">Atur Stok Produk</span></a></li>
            <li><a href="atur_status_produk.php" class="menu-item" data-menu="status"><span class="icon">📋</span><span class="menu-text">Atur Status Produk</span></a></li>
            <li><a href="kurir.php" class="menu-item" data-menu="courier"><span class="icon">🚚</span><span class="menu-text">Kurir</span></a></li>
            <li><a href="#" class="menu-item" data-menu="logout" onclick="confirmLogout()"><span class="icon">🚪</span><span class="menu-text">Logout</span></a></li>
        </ul>
    </nav>
</div>

<!-- Modal Upload Foto -->
<div id="photoModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Upload Foto Profil</h2>
        
        <?php if(isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="photo">Pilih Foto:</label>
                <input type="file" name="photo" id="photo" accept="image/*" required>
            </div>
            <div class="form-actions">
                <button type="submit" name="upload_photo" class="btn btn-primary">Upload</button>
            </div>
        </form>
    </div>
</div>

<style>

    /* Style dasar untuk konten */
.dashboard-content,
.content {
    margin-left: 250px;
    transition: margin-left 0.3s ease;
}

/* Saat sidebar ditutup */
.sidebar.closed ~ .dashboard-content,
.sidebar.closed ~ .content {
    margin-left: 50px;
}

/* Responsive - di bawah 768px, margin jadi 0 */
@media (max-width: 768px) {
    .dashboard-content,
    .content {
        margin-left: 0 !important;
    }
}

    /* Styling untuk sidebar dan toggle button */
    .toggle-btn {
        position: fixed;
        top: 15px;
        left: 15px;
        background: #333;
        color: white;
        border: none;
        font-size: 24px;
        width: 40px;
        height: 40px;
        border-radius: 5px;
        cursor: pointer;
        z-index: 100;
    }

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        width: 250px;
        height: 100%;
        background: #333;
        color: white;
        transition: all 0.3s ease;
        z-index: 99;
        overflow-y: auto;
    }

    .sidebar.closed {
        left: -250px;
    }

    .sidebar.open {
        left: 0;
    }

    .profile {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid #444;
    }

    .profile-img {
        width: 120px;
        height: 120px;
        margin: 0 auto 15px;
        position: relative;
    }
    
    .profile-photo-container {
        position: relative;
        width: 120px;
        height: 120px;
        border-radius: 50%;
        overflow: hidden;
        margin: 0 auto;
    }
    
    .profile-photo-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .edit-photo-icon {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.6);
        color: white;
        padding: 5px;
        cursor: pointer;
        font-size: 12px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s;
    }
    
    .profile-photo-container:hover .edit-photo-icon {
        opacity: 1;
    }

    .profile-info h3 {
        margin: 0 0 5px;
        font-size: 18px;
    }

    .profile-info p {
        margin: 0;
        font-size: 14px;
        opacity: 0.7;
    }

    .sidebar-menu {
        padding: 15px 0;
    }

    .sidebar-menu ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar-menu ul li {
        padding: 0;
    }

    .menu-item {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        color: white;
        text-decoration: none;
        transition: background 0.3s;
    }

    .menu-item:hover, .menu-item.active {
        background: #555;
    }

    .icon {
        margin-right: 15px;
        font-size: 18px;
        width: 20px;
        text-align: center;
    }
    
    /* Modal Styles */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.7);
    }
    
    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border-radius: 8px;
        width: 80%;
        max-width: 500px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        color: #333;
    }
    
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    
    .close:hover {
        color: black;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
    }
    
    .btn {
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    
    .btn:hover {
        background-color: #45a049;
    }
    
    .alert {
        padding: 12px;
        margin-bottom: 15px;
        border-radius: 4px;
    }
    
    .alert-danger {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
</style>

<script>
const toggleBtn = document.getElementById('toggleSidebar');
const sidebar = document.getElementById('sidebar');

// Mendengarkan klik pada tombol toggle
toggleBtn.addEventListener('click', () => {
    // Jika sidebar sedang tertutup, buka; kalau terbuka, tutup
    if (sidebar.classList.contains('closed')) {
        sidebar.classList.remove('closed');
        sidebar.classList.add('open');
    } else {
        sidebar.classList.remove('open');
        sidebar.classList.add('closed');
    }
});


// Modal functionality
const modal = document.getElementById('photoModal');
const editPhotoBtn = document.getElementById('editPhotoBtn');
const closeBtn = document.getElementsByClassName('close')[0];

// Open modal when click on edit button
editPhotoBtn.addEventListener('click', function() {
    modal.style.display = "block";
});

// Close modal when click on close button
closeBtn.addEventListener('click', function() {
    modal.style.display = "none";
});

// Close modal when click outside
window.addEventListener('click', function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
});

function confirmLogout() {
        if (confirm("Apakah Anda yakin ingin logout?")) {
            window.location.href = "../logic/process_logout.php";
        }
    }
</script>