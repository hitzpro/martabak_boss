<?php
session_start();
include '../config/db.php'; 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Martabak No Debat - Pilihan Pasti Untuk Pecinta Martabak</title>
    <link rel="stylesheet" href="../assets/css/index.css">
    <link rel="icon" href="../assets/icon/logo.png" type="image/png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<!-- Header Section -->
<header class="mnd-header">
    <div class="mnd-logo">
        <h1>MARTABAK NO DEBAT</h1>
    </div>
    <nav class="simple-navbar"> <!-- class sudah disamakan dengan nav 1 -->
        <div class="navbar-menu">
            <a href="#" class="active">Beranda</a>
            <a href="lihat_cabang.php">Lihat Cabang</a>
        </div>
        
        <div class="navbar-profile">
            <a href="login.php" class="mnd-login-btn">Masuk</a>
        </div>
    </nav>
</header>


    <!-- Hero Section -->
    <section class="mnd-hero">
        <div class="mnd-hero-content">
            <h2>SELAMAT DATANG DI</h2>
            <h1>MARTABAK NO DEBAT</h1>
            <p>Kami Hadir Dengan Resep Terbaik Dan Topping Pilihan, Disiapkan Dengan Penuh Cinta Dari Dapur Ke Tanganmu. Martabak No Debat, Pilihan Pasti Untuk Pecinta Martabak Sejati.</p>
            <a href="#products" class="mnd-scroll-btn">
                <i class="fas fa-chevron-down"></i>
            </a>
        </div>
        <div class="mnd-hero-overlay"></div>
    </section>

    <!-- Running Text -->
    <div class="mnd-running-text">
        <div class="mnd-running-text-content">
            <p>- Promo Spesial Bulan Ini - Beli 2 Martabak Gratis 1 - Promo Spesial Hari Ini - </p>
        </div>
    </div>

    <!-- Search Section -->
    <section class="mnd-search">
        <div class="mnd-container">
            <h2>Cari Martabak Kesukaan Anda Disini</h2>
            <div class="mnd-search-box">
                <input type="text" placeholder="Ketik Sesuatu Disini" class="mnd-search-input">
                <button class="mnd-search-btn">Cari</button>
            </div>
            <!-- <a href="#" class="mnd-see-all">Lihat selengkapnya</a> -->
        </div>
    </section>

    <!-- Products Carousel -->
    <section id="products" class="mnd-products">
        <div class="mnd-container">
            <div class="mnd-carousel-container">
                <button class="mnd-carousel-btn mnd-prev-btn" id="prevBtn">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <div class="mnd-carousel-wrapper">
                    <div class="mnd-carousel" id="productCarousel">
                        <!-- Produk akan dimuat oleh JS -->
                    </div>
                </div>
                <button class="mnd-carousel-btn mnd-next-btn" id="nextBtn">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
            <div class="mnd-carousel-pagination" id="carouselPagination"></div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="mnd-faq">
        <div class="mnd-container">
            <h2>FAQ</h2>
            <div class="mnd-faq-content">
                <div class="mnd-faq-left">
                    <div class="mnd-accordion">
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Gimana cara memesan di website ini ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Anda dapat memesan dengan memilih menu martabak yang diinginkan, klik tombol "Beli Sekarang", lalu ikuti proses checkout hingga selesai.</p>
                            </div>
                        </div>
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Bisa Bayar COD ga ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Ya, kami menerima pembayaran COD (Cash On Delivery) untuk pesanan dalam area pengiriman tertentu.</p>
                            </div>
                        </div>
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Cabangnya ada dimana aja nih ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Cabang Martabak No Debat tersebar di beberapa lokasi. Silakan kunjungi halaman "Lihat Cabang" untuk informasi lokasi terdekat dengan Anda.</p>
                            </div>
                        </div>
                        <div class="mnd-accordion-item">
                            <div class="mnd-accordion-header">
                                <h3>Cara Bayarnya gimana ?</h3>
                                <span class="mnd-accordion-icon">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </div>
                            <div class="mnd-accordion-content">
                                <p>Kami menerima berbagai metode pembayaran termasuk transfer bank, e-wallet (OVO, GoPay, Dana), kartu kredit, dan COD untuk area tertentu.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mnd-faq-right">
                    <img src="../assets/img/ilustrasi/faq.png" alt="FAQ Illustration">
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="mnd-footer">
        <div class="mnd-container">
            <p>2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <script src="../assets/js/index1.js"></script>
</body>
</html>
