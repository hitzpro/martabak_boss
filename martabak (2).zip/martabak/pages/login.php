<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Martabak No Debat</title>
    <link rel="stylesheet" href="../assets/css/login.css">
    <link rel="icon" href="../assets/icon/logo.png" type="image/png">
</head>
<body>
    <!-- Header section with logo and navigation -->
    <header class="mnd-header">
        <div class="mnd-container">
            <div class="mnd-logo">MARTABAK NO DEBAT</div>
            <nav class="mnd-nav">
                <a href="index.php" class="mnd-nav-link">Beranda</a>
            </nav>
        </div>
    </header>

    <main>
        <!-- Login/Register container -->
        <section class="mnd-login-section">
            <div class="mnd-login-container">
                <!-- Login form - Initially visible -->
                <div class="mnd-form-wrapper" id="loginFormWrapper">
                    <div class="mnd-login-form">
                        <h1 class="mnd-login-title">SELAMAT DATANG KEMBALI</h1>
                        
                        <!-- Login form will be processed by PHP -->
                        <form id="loginForm" action="../logic/process_login.php" method="POST">
                            <!-- Username field -->
                            <div class="mnd-form-group">
                                <label for="username" class="mnd-form-label">USERNAME</label>
                                <input 
                                    type="text" 
                                    id="username" 
                                    name="username" 
                                    class="mnd-form-input" 
                                    placeholder="Masukkan Username Anda"
                                    required
                                >
                                <!-- PHP will display validation errors here -->
                                <div class="mnd-error-message" id="username-error"></div>
                            </div>
                            
                            <!-- Password field -->
                            <div class="mnd-form-group">
                                <label for="password" class="mnd-form-label">PASSWORD</label>
                                <input 
                                    type="password" 
                                    id="password" 
                                    name="password" 
                                    class="mnd-form-input" 
                                    placeholder="Masukkan Password Anda"
                                    required
                                >
                                <!-- PHP will display validation errors here -->
                                <div class="mnd-error-message" id="password-error"></div>
                            </div>
                            
                            <!-- Login button - Will trigger form submission to PHP -->
                            <button type="submit" class="mnd-button mnd-button-primary">Masuk</button>
                            
                            <!-- Additional links -->
                            <div class="mnd-form-links">
                                <!-- Toggle button to show registration form -->
                                <button type="button" id="showRegisterForm" class="mnd-button mnd-button-secondary">Daftar</button>
                                
                                <!-- Link to forgot password page -->
                                <a href="lupa_password.php" class="mnd-button mnd-button-secondary">Lupa Password</a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Registration form - Initially hidden -->
                <div class="mnd-form-wrapper hidden" id="registerFormWrapper">
                    <div class="mnd-login-form">
                        <h1 class="mnd-login-title">DAFTAR AKUN BARU</h1>
                        
                        <!-- Registration form will be processed by PHP -->
                        <form id="registerForm" action="../logic/public/process_register.php" method="POST">
                            <!-- Email field -->
                            <div class="mnd-form-group">
                                <label for="email" class="mnd-form-label">EMAIL</label>
                                <input 
                                    type="email" 
                                    id="email" 
                                    name="email" 
                                    class="mnd-form-input" 
                                    placeholder="Masukkan Email Anda"
                                    required
                                >
                                <div class="mnd-error-message" id="email-error"></div>
                            </div>
                            
                            <!-- Name field -->
                            <div class="mnd-form-group">
                                <label for="name" class="mnd-form-label">NAMA LENGKAP</label>
                                <input 
                                    type="text" 
                                    id="name" 
                                    name="name" 
                                    class="mnd-form-input" 
                                    placeholder="Masukkan Nama Lengkap Anda"
                                    required
                                >
                                <div class="mnd-error-message" id="name-error"></div>
                            </div>
                            
                            <!-- Password field with recommendations -->
                            <div class="mnd-form-group">
                                <label for="reg-password" class="mnd-form-label">PASSWORD</label>
                                <input 
                                    type="password" 
                                    id="reg-password" 
                                    name="password" 
                                    class="mnd-form-input" 
                                    placeholder="Buat Password Anda"
                                    required
                                >
                                <div class="mnd-password-strength" id="password-strength"></div>
                                <div class="mnd-password-tips">
                                    <p>Rekomendasi password yang kuat:</p>
                                    <ul>
                                        <li>Minimal 8 karakter</li>
                                        <li>Kombinasi huruf besar dan kecil</li>
                                        <li>Sertakan angka dan simbol</li>
                                    </ul>
                                </div>
                                <div class="mnd-error-message" id="reg-password-error"></div>
                            </div>
                            
                            <!-- Register button -->
                            <button type="submit" class="mnd-button mnd-button-primary">Daftar Sekarang</button>
                            
                            <!-- Back to login button -->
                            <button type="button" id="backToLogin" class="mnd-button mnd-button-secondary">Kembali ke Login</button>
                        </form>
                    </div>
                </div>
                
                <!-- Illustration image - Using placeholder for now -->
                <div class="mnd-login-illustration">
                    <!-- PHP can dynamically load different images here -->
                    <img src="../assets/img/ilustrasi/cook.png" alt="Chef Illustration" class="mnd-illustration-img">

                </div>
            </div>
        </section>
    </main>

    <!-- Footer section -->
    <footer class="mnd-footer">
        <div class="mnd-container">
            <p class="mnd-copyright">2025 Copyright | Martabak No Debat</p>
        </div>
    </footer>

    <!-- JavaScript file with correct path -->
    <script src="../assets/js/login.js"></script>
</body>
</html>