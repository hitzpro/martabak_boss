<?php
$host = "localhost";
$user = "root"; // ganti jika pakai user lain
$pass = "";     // ganti jika pakai password
$db   = "martabak";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
