<?php
session_start();
require_once '../../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    echo json_encode(['success' => false, 'message' => 'User tidak login']);
    exit;
}

$user_id = $_SESSION['id'];

// Query untuk mendapatkan item di keranjang dengan nama produk
$sql = "SELECT k.id, k.user_id, k.produk_id, k.jumlah, k.harga, p.nama as nama_produk 
        FROM keranjang k 
        JOIN produk p ON k.produk_id = p.id 
        WHERE k.user_id = ?
        ORDER BY k.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
    echo json_encode(['success' => true, 'items' => $items]);
} else {
    echo json_encode(['success' => true, 'items' => []]);
}

$stmt->close();
$conn->close();
?>