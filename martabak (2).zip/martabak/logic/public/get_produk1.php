<?php
include '../../config/db.php'; // koneksi database

$query = "SELECT * FROM produk ORDER BY id ASC";
$result = mysqli_query($conn, $query);

$products = [];
while ($row = mysqli_fetch_assoc($result)) {
    $row['gambar'] = '../assets/img/produk/' . $row['gambar']; // path gambar
    $products[] = $row;
}

echo json_encode($products);
?>
