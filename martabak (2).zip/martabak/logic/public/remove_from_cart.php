<?php
session_start();
require_once '../../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    echo json_encode(['success' => false, 'message' => 'User tidak login']);
    exit;
}

// Check if item ID is provided
if (!isset($_POST['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID item tidak disediakan']);
    exit;
}

$user_id = $_SESSION['id'];
$item_id = $_POST['id'];

// Verify item belongs to user before deleting
$stmt = $conn->prepare("SELECT user_id FROM keranjang WHERE id = ?");
$stmt->bind_param("i", $item_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Item tidak ditemukan']);
    exit;
}

$item = $result->fetch_assoc();
if ($item['user_id'] != $user_id) {
    echo json_encode(['success' => false, 'message' => 'Anda tidak memiliki akses ke item ini']);
    exit;
}

// Delete item from cart
$stmt = $conn->prepare("DELETE FROM keranjang WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $item_id, $user_id);
$result = $stmt->execute();

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Item berhasil dihapus dari keranjang']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menghapus item dari keranjang']);
}

$stmt->close();
$conn->close();
?>