<?php
session_start();
include '../../config/db.php';

// Ambil data dari form
$email = mysqli_real_escape_string($conn, $_POST['email']);
$name = mysqli_real_escape_string($conn, $_POST['name']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

// Validasi sederhana (boleh kamu kembangkan lagi)
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<script>alert('Email tidak valid!'); window.history.back();</script>";
    exit;
}

// Cek apakah email sudah terdaftar
$check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
if (mysqli_num_rows($check) > 0) {
    echo "<script>alert('Email sudah digunakan!'); window.history.back();</script>";
    exit;
}

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Simpan data ke database
$query = "INSERT INTO users (username, password, email, umur, alamat_lengkap, role) 
          VALUES ('$name', '$hashedPassword', '$email', NULL, NULL, 'user')";

if (mysqli_query($conn, $query)) {
    echo "<script>alert('Pendaftaran berhasil! Silakan login.'); window.location.href='../../pages/login.php';</script>";
} else {
    echo "<script>alert('Terjadi kesalahan saat mendaftar!'); window.history.back();</script>";
}
?>
