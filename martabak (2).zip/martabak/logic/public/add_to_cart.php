<?php
session_start();
require_once '../../config/db.php';

// Atur header supaya selalu return JSON
header('Content-Type: application/json');
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Pastikan POST data tersedia
if (!isset($_POST['produk_id'], $_POST['jumlah'])) {
    echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
    exit;
}

if (!isset($_SESSION['id'])) {
    echo json_encode(['success' => false, 'message' => 'User belum login']);
    exit;
}
$user_id = $_SESSION['id'];
$produk_id = (int) $_POST['produk_id'];
$jumlah = (int) $_POST['jumlah'];

// Ambil harga produk
$stmt = $conn->prepare("SELECT harga FROM produk WHERE id = ?");
$stmt->bind_param("i", $produk_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Produk tidak ditemukan']);
    exit;
}

$product = $result->fetch_assoc();
$harga = $product['harga'];

// Cek apakah produk sudah ada di keranjang
$stmt = $conn->prepare("SELECT id, jumlah FROM keranjang WHERE user_id = ? AND produk_id = ?");
$stmt->bind_param("ii", $user_id, $produk_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update jumlah
    $cart_item = $result->fetch_assoc();
    $new_jumlah = $cart_item['jumlah'] + $jumlah;

    $stmt = $conn->prepare("UPDATE keranjang SET jumlah = ? WHERE id = ?");
    $stmt->bind_param("ii", $new_jumlah, $cart_item['id']);
    $success = $stmt->execute();
} else {
    // Insert baru
    $stmt = $conn->prepare("INSERT INTO keranjang (user_id, produk_id, jumlah, harga) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiid", $user_id, $produk_id, $jumlah, $harga);
    $success = $stmt->execute();
}

if ($success) {
    echo json_encode(['success' => true, 'message' => 'Produk berhasil ditambahkan ke keranjang']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menambahkan produk ke keranjang']);
}

$stmt->close();
$conn->close();
