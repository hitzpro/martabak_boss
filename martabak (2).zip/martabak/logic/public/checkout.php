<?php
session_start();
require '../../config/db.php'; // Koneksi database

// Cek login
if (!isset($_SESSION['id'])) {
    die("Akses ditolak. Silakan login terlebih dahulu.");
}

$userId = $_SESSION['id'];

// Ambil data dari form
$produkId = $_POST['produk_id'];
$jenis = $_POST['jenisMartabak'];
$varian = $_POST['varianMartabak'];
$jumlah = intval($_POST['jumlahPesan']);
$catatan = $_POST['catatan'] ?? '';
$bukti = $_FILES['uploadBukti'];

// ====================
// LANGKAH 1: Hapus dari keranjang jika sudah ada
// ====================
$queryCheck = "SELECT * FROM keranjang WHERE user_id = ? AND produk_id = ?";
$stmtCheck = $conn->prepare($queryCheck);
$stmtCheck->bind_param("ii", $userId, $produkId);
$stmtCheck->execute();
$result = $stmtCheck->get_result();

if ($result->num_rows > 0) {
    $queryDelete = "DELETE FROM keranjang WHERE user_id = ? AND produk_id = ?";
    $stmtDelete = $conn->prepare($queryDelete);
    $stmtDelete->bind_param("ii", $userId, $produkId);
    $stmtDelete->execute();
}

// Mulai transaksi
$conn->begin_transaction();

try {
    // ====================
    // LANGKAH 2: Ambil data user dan produk
    // ====================
    $stmtNamaUser = $conn->prepare("SELECT username, alamat_lengkap FROM users WHERE id = ?");
    $stmtNamaUser->bind_param("i", $userId);
    $stmtNamaUser->execute();
    $resultUser = $stmtNamaUser->get_result();
    $userData = $resultUser->fetch_assoc();
    $namaUser = $userData['username'];
    $alamat = $userData['alamat_lengkap'];

    $stmtProduk = $conn->prepare("SELECT nama, harga, stok FROM produk WHERE id = ?");
    $stmtProduk->bind_param("i", $produkId);
    $stmtProduk->execute();
    $resultProduk = $stmtProduk->get_result();
    $produkData = $resultProduk->fetch_assoc();

    $namaProduk = $produkData['nama'];
    $harga = $produkData['harga'];
    $stokSekarang = $produkData['stok'];

    if ($stokSekarang < $jumlah) {
        throw new Exception("Stok tidak mencukupi untuk produk ini.");
    }

    $hargaTotal = $harga * $jumlah;

    // ====================
    // LANGKAH 3: Simpan ke tabel `pemesanan`
    // ====================
    $statusPemesanan = 'menunggu konfirmasi';
    $stmtPemesanan = $conn->prepare("INSERT INTO pemesanan (user_id, nama_user, produk_id, nama_produk, jumlah, harga_total, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmtPemesanan->bind_param("isissds", $userId, $namaUser, $produkId, $namaProduk, $jumlah, $hargaTotal, $statusPemesanan);
    $stmtPemesanan->execute();
    $pemesananId = $conn->insert_id;

    // ====================
    // LANGKAH 4: Upload bukti pembayaran
    // ====================
    $uploadDir = "../../buktiPembayaran/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $namaUserClean = preg_replace('/[^a-zA-Z0-9_]/', '_', $namaUser);
    $tanggal = date('Y-m-d');
    $ext = pathinfo($bukti['name'], PATHINFO_EXTENSION);
    $buktiName = "ID{$userId}_bukti_pembayaran_{$namaUserClean}_{$tanggal}." . $ext;
    $targetFile = $uploadDir . $buktiName;

    if (!move_uploaded_file($bukti['tmp_name'], $targetFile)) {
        throw new Exception("Gagal upload bukti pembayaran.");
    }

    // ====================
    // LANGKAH 5: Simpan ke tabel `pesanan`
    // ====================
    $status = 'pending';
    $stmtInsert = $conn->prepare("INSERT INTO pesanan (user_id, produk_id, jumlah, jenis_martabak, varian_martabak, catatan, alamat, bukti_pembayaran, status, pesanan_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmtInsert->bind_param("iiissssssi", $userId, $produkId, $jumlah, $jenis, $varian, $catatan, $alamat, $buktiName, $status, $pemesananId);
    $stmtInsert->execute();

    // ====================
    // LANGKAH 6: Kurangi stok
    // ====================
    $stokBaru = max(0, $stokSekarang - $jumlah);
    $stmtUpdateStok = $conn->prepare("UPDATE produk SET stok = ? WHERE id = ?");
    $stmtUpdateStok->bind_param("ii", $stokBaru, $produkId);
    $stmtUpdateStok->execute();

    // Commit transaksi
    $conn->commit();

    echo "<script>alert('Pesanan berhasil diproses!'); window.location.href='../../pages/login_user/lihat_status_pesanan.php';</script>";
    exit;

} catch (Exception $e) {
    $conn->rollback();
    echo "<script>alert('Terjadi kesalahan: " . $e->getMessage() . "'); window.history.back();</script>";
    exit;
}
?>
