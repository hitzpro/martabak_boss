<?php
session_start();
include '../config/db.php';

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

// Cek apakah username ada
$query = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
$data = mysqli_fetch_assoc($query);

if ($data && password_verify($password, $data['password'])) {
    $_SESSION['id']     = $data['id'];
    $_SESSION['nama']   = $data['username'];
    $_SESSION['role']   = $data['role'];

    $nama = $data['username'];

    if ($data['role'] == 'admin') {
        echo "<script>alert('Selamat datang, $nama!'); window.location.href='../admin/dashboard.php';</script>";
    } elseif ($data['role'] == 'user') {
        echo "<script>alert('Selamat datang, $nama!'); window.location.href='../pages/login_user/index.php';</script>";
    } else {
        echo "<script>alert('User tidak dikenali.'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Login gagal! Periksa kembali username dan password.'); window.history.back();</script>";
}
?>
