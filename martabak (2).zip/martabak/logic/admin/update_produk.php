<?php
// Set header first to ensure no HTML is sent before JSON
header('Content-Type: application/json');

// Koneksi ke database
require_once '../../config/db.php';

// Check if database connection exists
if (!isset($conn)) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Mendapatkan ID produk yang akan diupdate
$productId = isset($_GET['id']) ? $_GET['id'] : null;

if (!$productId) {
    echo json_encode(['success' => false, 'message' => 'Product ID is required']);
    exit;
}

// Mengecek apakah data POST ada
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mendapatkan data dari form
    $productName = $_POST['productName'] ?? '';
    $productDescription = $_POST['productDescription'] ?? '';
    $productStock = $_POST['productStock'] ?? 0;
    $productPrice = $_POST['productPrice'] ?? 0;
    
    // Get the existing image from database
    $query = "SELECT gambar FROM produk WHERE id = " . $productId;
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $existingImage = $row ? $row['gambar'] : null;

    // Mengambil gambar baru jika ada
    $productImage = $existingImage; // Default to existing image
    if (isset($_FILES['productImage']) && $_FILES['productImage']['error'] === 0) {
        // Proses upload gambar baru
        $uploadDir = '../../assets/img/produk/';
        $productImage = time() . '_' . $_FILES['productImage']['name'];
        
        // Make sure the directory exists
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        if (move_uploaded_file($_FILES['productImage']['tmp_name'], $uploadDir . $productImage)) {
            // Delete old image if exists and it's not a default image
            if ($existingImage && file_exists($uploadDir . $existingImage) && $existingImage != 'default.jpg') {
                unlink($uploadDir . $existingImage);
            }
        } else {
            $productImage = $existingImage; // Keep old image if upload fails
        }
    }

    try {
        // Escape strings to prevent SQL injection
        $productName = mysqli_real_escape_string($conn, $productName);
        $productDescription = mysqli_real_escape_string($conn, $productDescription);
        $productImage = mysqli_real_escape_string($conn, $productImage);
        
        // Query untuk update data produk
        $query = "UPDATE produk SET 
                  nama = '$productName', 
                  deskripsi = '$productDescription', 
                  stok = $productStock, 
                  harga = $productPrice, 
                  gambar = '$productImage' 
                  WHERE id = $productId";
                  
        $result = mysqli_query($conn, $query);

        // Mengembalikan respon dalam format JSON
        if ($result && mysqli_affected_rows($conn) > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No changes made or product not found: ' . mysqli_error($conn)]);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>