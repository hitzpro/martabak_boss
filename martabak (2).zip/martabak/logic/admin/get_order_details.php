<?php
// Set header to JSON
header('Content-Type: application/json');

// Include database connection
require_once '../../config/db.php';

// Check if ID is provided
if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Order ID is required']);
    exit;
}

$orderId = (int)$_GET['id'];

// Query to get order details
$query = "SELECT * FROM pemesanan WHERE id = $orderId";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    exit;
}

// Fetch order details
$order = mysqli_fetch_assoc($result);

if (!$order) {
    echo json_encode(['success' => false, 'message' => 'Order not found']);
    exit;
}

// Return order details as JSON
echo json_encode($order);
?>