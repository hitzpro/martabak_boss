<?php
// File: api/get_order_details.php
header('Content-Type: application/json');

// Include database connection
include_once '../../config/db.php';

if (isset($_GET['id'])) {
    $pemesanan_id = $_GET['id'];
    
    // Query to get order details from the pemesanan table based on your actual table structure
    $sql = "SELECT id, nama_user, nama_produk, jumlah, harga_total, status 
            FROM pemesanan 
            WHERE id = $pemesanan_id";
    
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $order = $result->fetch_assoc();
        
        // Prepare the details text
        $details = "Pesanan #" . $order['id'] . "\n";
        $details .= "Produk: " . $order['nama_produk'] . "\n";
        $details .= "Jumlah: " . $order['jumlah'] . "\n";
        $details .= "Total: Rp " . number_format($order['harga_total'], 0, ',', '.') . "\n";
        
        echo json_encode(['success' => true, 'details' => $details]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Pesanan tidak ditemukan']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'ID pesanan tidak valid']);
}