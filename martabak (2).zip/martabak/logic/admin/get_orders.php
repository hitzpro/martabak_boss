<?php
// Set header to JSON
header('Content-Type: application/json');

// Include database connection
require_once '../../config/db.php';

// Query to get all orders
$query = "SELECT * FROM pemesanan ORDER BY id DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    exit;
}

// Fetch all orders
$orders = [];
while ($row = mysqli_fetch_assoc($result)) {
    $orders[] = $row;
}

// Return orders as JSON
echo json_encode($orders);
?>