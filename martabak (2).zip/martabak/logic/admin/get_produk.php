<?php
header('Content-Type: application/json');
include '../../config/db.php';


if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM produk WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode(['error' => 'Produk tidak ditemukan']);
    }
} else {
    echo json_encode(['error' => 'ID tidak ditemukan']);
}

$conn->close();
?>
