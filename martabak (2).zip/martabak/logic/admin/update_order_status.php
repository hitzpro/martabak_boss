<?php
// Ensure no output buffering that might cause issues
ob_clean();

// Force no output before our JSON
// Turn off all error reporting
error_reporting(0);
ini_set('display_errors', 0);

// Set header to JSON
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');

// Ensure we're starting with a clean output buffer
if (ob_get_level()) ob_end_clean();

try {
    // Include database connection
    require_once '../../config/db.php';
    
    // Get JSON data from request
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);
    
    // Check if JSON was parsed correctly
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data: ' . json_last_error_msg());
    }
    
    // Check if data is valid
    if (!isset($data['id']) || !isset($data['status'])) {
        throw new Exception('Missing required fields: id or status');
    }
    
    $orderId = (int)$data['id'];
    $status = mysqli_real_escape_string($conn, $data['status']);
    $notes = isset($data['notes']) ? mysqli_real_escape_string($conn, $data['notes']) : '';
    
    // Validate status
    $validStatuses = ['menunggu konfirmasi', 'sedang diproses', 'sedang dikirim', 'dibatalkan', 'selesai'];
    if (!in_array(strtolower($status), $validStatuses)) {
        throw new Exception('Invalid status: ' . $status);
    }
    
    // Start transaction
    mysqli_autocommit($conn, false);
    
    // Update order status
    $query = "UPDATE pemesanan SET status = '$status' WHERE id = $orderId";
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        throw new Exception('Database error on update pemesanan: ' . mysqli_error($conn));
    }
    
    // Only proceed with other operations if the pemesanan update was successful
    if (mysqli_affected_rows($conn) > 0) {
        // Get the related pesanan_id from pemesanan table
        $pesananQuery = "SELECT pesanan_id FROM pemesanan WHERE id = $orderId";
        $pesananResult = mysqli_query($conn, $pesananQuery);
        
        if ($pesananResult && mysqli_num_rows($pesananResult) > 0) {
            $pesananData = mysqli_fetch_assoc($pesananResult);
            $pesananId = isset($pesananData['pesanan_id']) ? (int)$pesananData['pesanan_id'] : 0;
            
            // Update status in pesanan table based on pemesanan status
            if ($pesananId > 0) {
                $pesananStatus = '';
                
                if ($status === 'sedang diproses') {
                    $pesananStatus = 'dikonfirmasi';
                } else if ($status === 'selesai') {
                    $pesananStatus = 'selesai';
                } else if ($status === 'dibatalkan') {
                    $pesananStatus = 'batal';
                }
                
                if (!empty($pesananStatus)) {
                    $updatePesananQuery = "UPDATE pesanan SET status = '$pesananStatus' WHERE id = $pesananId";
                    $updatePesananResult = mysqli_query($conn, $updatePesananQuery);
                    
                    if (!$updatePesananResult) {
                        throw new Exception('Database error on update pesanan: ' . mysqli_error($conn));
                    }
                }
            }
        }
    
        // If status is "sedang dikirim", add entry to kurir table
        if ($status === 'sedang dikirim') {
            // Get pemesanan and user info
            $query = "SELECT p.id, p.user_id, p.nama_user, p.produk_id, u.alamat_lengkap, p.nama_produk 
                    FROM pemesanan p
                    LEFT JOIN users u ON p.user_id = u.id
                    WHERE p.id = $orderId";
            
            $result = mysqli_query($conn, $query);
            
            if (!$result) {
                throw new Exception('Database error on select: ' . mysqli_error($conn));
            }
            
            $orderData = mysqli_fetch_assoc($result);
            
            if (!$orderData) {
                throw new Exception('Order not found');
            }
            
            // Check if entry already exists in kurir table
            $checkQuery = "SELECT id FROM kurir WHERE pemesanan_id = $orderId";
            $checkResult = mysqli_query($conn, $checkQuery);
            
            if (!$checkResult) {
                throw new Exception('Database error on check kurir: ' . mysqli_error($conn));
            }
            
            // If entry doesn't exist, insert new entry
            if (mysqli_num_rows($checkResult) === 0) {
                $nama_pelanggan = mysqli_real_escape_string($conn, $orderData['nama_user']);
                
                // Fix the address handling
                $alamat = !empty($orderData['alamat_lengkap']) ? 
                        mysqli_real_escape_string($conn, $orderData['alamat_lengkap']) : 
                        'Alamat tidak tersedia';
                
                // If we need to check for pesanan table for address
                if ($alamat === 'Alamat tidak tersedia') {
                    // Try to get address from pesanan table
                    $pesananAddressQuery = "SELECT alamat FROM pesanan WHERE user_id = " . (int)$orderData['user_id'] . " ORDER BY id DESC LIMIT 1";
                    $pesananAddressResult = mysqli_query($conn, $pesananAddressQuery);
                    
                    if ($pesananAddressResult && mysqli_num_rows($pesananAddressResult) > 0) {
                        $pesananAddressData = mysqli_fetch_assoc($pesananAddressResult);
                        if (!empty($pesananAddressData['alamat'])) {
                            $alamat = mysqli_real_escape_string($conn, $pesananAddressData['alamat']);
                        }
                    }
                }
                
                $insertQuery = "INSERT INTO kurir (pemesanan_id, nama_pelanggan, alamat_pengiriman, status_pengiriman, catatan) 
                            VALUES ($orderId, '$nama_pelanggan', '$alamat', 'menunggu pengiriman', '$notes')";
                
                $insertResult = mysqli_query($conn, $insertQuery);
                
                if (!$insertResult) {
                    throw new Exception('Database error on insert kurir: ' . mysqli_error($conn));
                }
            } else {
                // If entry exists, update it
                $updateQuery = "UPDATE kurir SET status_pengiriman = 'menunggu pengiriman', catatan = '$notes' 
                            WHERE pemesanan_id = $orderId";
                
                $updateResult = mysqli_query($conn, $updateQuery);
                
                if (!$updateResult) {
                    throw new Exception('Database error on update kurir: ' . mysqli_error($conn));
                }
            }
        }
    }
    
    // Commit transaction if everything is successful
    mysqli_commit($conn);
    $response = ['success' => true];
    die(json_encode($response));
    
} catch (Exception $e) {
    // Roll back transaction if there was an error
    if (isset($conn)) {
        mysqli_rollback($conn);
        mysqli_autocommit($conn, true);
    }
    
    // Return error message as JSON
    $response = ['success' => false, 'message' => $e->getMessage()];
    die(json_encode($response));
} finally {
    // Restore autocommit if connection exists
    if (isset($conn)) {
        mysqli_autocommit($conn, true);
    }
}
// Make sure nothing follows after this
?>