<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atur dan Edit Produk</title>
    <link rel="stylesheet" href="../assets/css/atur_produk.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="icon" href="../assets/icon/logo.png" type="image/png">

</head>
<body>
    <div class="container">
        <?php include '../pages/include/sidebar.php'; ?>

        <div class="content">
            <div class="header">
                <h1>Atur dan Edit Produk</h1>
            </div>

            <div class="product-grid">
            <?php
            include '../config/db.php';

            $sql = "SELECT * FROM produk";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '
                    <div class="product-card" data-id="' . $row['id'] . '">
                        <div class="product-image">
                            <img src="../assets/img/produk/' . $row['gambar'] . '" alt="' . htmlspecialchars($row['nama']) . '">
                        </div>
                        <h3 class="product-title">' . htmlspecialchars($row['nama']) . '</h3>
                        <p class="product-description">' . htmlspecialchars($row['deskripsi']) . '</p>
                        <div class="stok-harga">
                            <p class="stock-info">Stok: ' . $row['stok'] . '</p>
                            <p class="price-info">Rp ' . number_format($row['harga'], 0, ',', '.') . '</p>
                        </div>
                        <button class="edit-btn" data-id="' . $row['id'] . '">Edit</button>
                    </div>';
                    
                }
            } else {
                echo '<p>Tidak ada produk tersedia.</p>';
            }

            $conn->close();
            ?>
        </div>

        </div>
    </div>

    <!-- Modal for editing products -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit Produk</h2>
            <form id="editProductForm">
                <input type="hidden" id="productId">
                
                <div class="form-group">
                    <label for="productName">Nama Produk</label>
                    <input type="text" id="productName" name="productName" required>
                </div>
                
                <div class="form-group">
                    <label for="productDescription">Deskripsi</label>
                    <textarea id="productDescription" name="productDescription" required></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group half">
                        <label for="productStock">Stok</label>
                        <input type="number" id="productStock" name="productStock" min="0" required>
                    </div>
                    
                    <div class="form-group half">
                        <label for="productPrice">Harga (Rp.)</label>
                        <input type="number" id="productPrice" name="productPrice" min="0" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="productImage">Gambar Produk</label>
                    <input type="file" id="productImage" name="productImage">
                </div>
                
                <div class="form-buttons">
                    <button type="button" class="btn-cancel">Batal</button>
                    <button type="submit" class="btn-save">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../assets/js/atur_produk.js"></script>
</body>
</html>