<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atur Status Pesanan</title>
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/atur_status.css">
    <link rel="icon" href="../assets/icon/logo.png" type="image/png">

</head>
<body>
    <div class="container">
        <?php include '../pages/include/sidebar.php'; ?>

        <div class="content">
            <div class="header">
                <h1>Atur Status Pesanan</h1>
            </div>

            <div class="orders-container">
                <div class="orders-table">
                    <div class="table-header">
                        <div class="col-number">No</div>
                        <div class="col-name">Nama User</div>
                        <div class="col-order">Pesanan User</div>
                        <div class="col-action">Aksi</div>
                    </div>
                    
                    <div class="table-body">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for editing order status -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Ubah Status Pesanan</h2>
            <form id="editStatusForm">
                <input type="hidden" id="orderId">
                
                <div class="form-group">
                    <label for="customerName">Nama Pelanggan</label>
                    <input type="text" id="customerName" readonly>
                </div>
                
                <div class="form-group">
                    <label for="orderDetails">Detail Pesanan</label>
                    <input type="text" id="orderDetails" readonly>
                </div>

                <div class="form-group">
                    <label for="orderDetails">Total Harga Pesanan</label>
                    <input type="text" id="orderPrice" readonly>
                </div>
                
                <div class="form-group">
                    <label for="orderStatus">Status Pesanan</label>
                    <select id="orderStatus" name="orderStatus" required>
                        <option value="">Pilih Status</option>
                        <option value="menunggu konfirmasi">Menunggu Konfirmasi</option>
                        <option value="sedang diproses">Sedang Diproses</option>
                        <option value="sedang dikirim">Sedang Dikirim</option>
                        <option value="dibatalkan">Dibatalkan</option>
                        <option value="dibatalkan">Selesai</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="statusNote">Catatan (Opsional)</label>
                    <textarea id="statusNote" name="statusNote"></textarea>
                </div>
                
                <div class="form-buttons">
                    <button type="button" class="btn-cancel">Batal</button>
                    <button type="submit" class="btn-save">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../assets/js/atur_status.js"></script>
</body>
</html>