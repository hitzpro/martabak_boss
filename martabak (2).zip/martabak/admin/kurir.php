<?php
include_once '../config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $delivery_id = $_POST['delivery_id'];
    $status = $_POST['deliveryStatus'];
    $note = $_POST['courierNote'];
    
    // Update the kurir table
    $updateKurir = "UPDATE kurir SET status_pengiriman = '$status', catatan = '$note' WHERE id = $delivery_id";
    $conn->query($updateKurir);
    
    // If status is "sudah diterima"
    if ($status === 'sudah diterima') {
        // Get pemesanan_id from kurir table
        $kurir_query = "SELECT pemesanan_id FROM kurir WHERE id = $delivery_id";
        $kurir_result = $conn->query($kurir_query);
        
        if ($kurir_result && $kurir_result->num_rows > 0) {
            $kurir_row = $kurir_result->fetch_assoc();
            $pemesanan_id = $kurir_row['pemesanan_id'];
            
            // Get details from pemesanan table
            $pemesanan_query = "SELECT user_id, harga_total, pesanan_id FROM pemesanan WHERE id = $pemesanan_id";
            $pemesanan_result = $conn->query($pemesanan_query);
            
            if ($pemesanan_result && $pemesanan_result->num_rows > 0) {
                $pemesanan_row = $pemesanan_result->fetch_assoc();
                $user_id = $pemesanan_row['user_id'];
                $total_harga = $pemesanan_row['harga_total'];
                $pesanan_id = $pemesanan_row['id'];
                
                // Insert into transaksi table
                $insert_transaksi = "INSERT INTO transaksi (user_id, tanggal_pesan, total_harga, status) 
                                    VALUES ($user_id, NOW(), $total_harga, 'berhasil')";
                $conn->query($insert_transaksi);
                
                // Update pemesanan status to "selesai"
                $updatePemesanan = "UPDATE pemesanan SET status = 'selesai' WHERE id = $pemesanan_id";
                $conn->query($updatePemesanan);
                
                // Update pesanan status to "selesai"
                if ($pesanan_id) {
                    $updatePesanan = "UPDATE pesanan SET status = 'selesai' WHERE pesanan_id = $pesanan_id";
                    if ($conn->query($updatePesanan)) {
                        echo "Pesanan berhasil diupdate ke status selesai.";
                    } else {
                        echo "Gagal update status pesanan: " . $conn->error;
                    }
                }
                
            }
        }
    }
    
    // Redirect back to the same page to refresh data
    header("Location: $_SERVER[PHP_SELF]");
    exit();
}

// Check if delete button was clicked
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_completed'])) {
    // Delete all records with status "sudah diterima"
    $deleteQuery = "DELETE FROM kurir WHERE status_pengiriman = 'sudah diterima'";
    $deleteResult = $conn->query($deleteQuery);
    
    // Redirect back to the same page to refresh data
    header("Location: $_SERVER[PHP_SELF]");
    exit();
}

// Get all deliveries with pemesanan_id information
$sql = "SELECT k.id, k.pemesanan_id, k.nama_pelanggan, k.alamat_pengiriman, k.status_pengiriman, k.catatan 
        FROM kurir k 
        ORDER BY k.id DESC";
$result = $conn->query($sql);

$deliveries = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Convert to correct data types for JavaScript
        $row['id'] = (int)$row['id'];
        $row['pemesanan_id'] = (int)$row['pemesanan_id'];
        $deliveries[] = $row;
    }
}

// Check if there are any completed deliveries
$hasCompletedDeliveries = false;
foreach ($deliveries as $delivery) {
    if ($delivery['status_pengiriman'] === 'sudah diterima') {
        $hasCompletedDeliveries = true;
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kurir</title>
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kurir.css">
    <link rel="icon" href="../assets/icon/logo.png" type="image/png">

    <style>
        .actions-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 15px;
        }
        
        .btn-delete-completed {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        
        .btn-delete-completed:hover {
            background-color: #c9302c;
        }
        
        .btn-delete-completed:disabled {
            background-color: #f5a3a1;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include '../pages/include/sidebar.php'; ?>

        <div class="content">
            <div class="header">
                <h1>Manajemen Pengiriman</h1>
            </div>

            <div class="actions-container">
                <form id="deleteCompletedForm" method="POST" onsubmit="return confirmDelete()">
                    <input type="hidden" name="delete_completed" value="1">
                    <button type="submit" class="btn-delete-completed" <?= $hasCompletedDeliveries ? '' : 'disabled' ?>>
                        Hapus Semua Pengiriman Selesai
                    </button>
                </form>
            </div>

            <div class="delivery-container">
                <div class="delivery-table">
                    <div class="table-header">
                        <div class="col-number">No</div>
                        <div class="col-name">Nama User</div>
                        <div class="col-address">Alamat</div>
                        <div class="col-action">Aksi</div>
                    </div>
                    
                    <div class="table-body">
                        <?php 
                        $counter = 1;
                        foreach ($deliveries as $delivery): 
                        ?>
                            <div class="table-row <?= $delivery['status_pengiriman'] === 'sudah diterima' ? 'completed-delivery' : '' ?>">
                                <div class="col-number"><?= $counter++ ?></div>
                                <div class="col-name"><?= htmlspecialchars($delivery['nama_pelanggan']) ?></div>
                                <div class="col-address"><?= htmlspecialchars($delivery['alamat_pengiriman']) ?></div>
                                <div class="col-action">
                                    <button class="btn-detail" data-id="<?= $delivery['id'] ?>">Detail</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if (empty($deliveries)): ?>
                            <div class="table-row">
                                <div class="no-data" colspan="4">Tidak ada data pengiriman</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for editing delivery status -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Ubah Status Pengiriman</h2>
            <form id="editDeliveryForm" method="POST" action="">
                <input type="hidden" id="deliveryId" name="delivery_id">
                <input type="hidden" name="update_status" value="1">
                
                <div class="form-group">
                    <label for="customerName">Nama Pelanggan</label>
                    <input type="text" id="customerName" readonly>
                </div>
                
                <div class="form-group">
                    <label for="orderDetails">Detail Pesanan</label>
                    <textarea id="orderDetails" readonly></textarea>
                </div>
                
                <div class="form-group">
                    <label for="deliveryAddress">Alamat Pengiriman</label>
                    <textarea id="deliveryAddress" readonly></textarea>
                </div>
                
                <div class="form-group">
                    <label for="deliveryStatus">Status Pengiriman</label>
                    <select id="deliveryStatus" name="deliveryStatus" required>
                        <option value="">Pilih Status</option>
                        <option value="menunggu pengiriman">Menunggu Pengiriman</option>
                        <option value="sedang dijemput">Sedang Dijemput</option>
                        <option value="sedang dikirim">Sedang Dikirim</option>
                        <option value="sudah diterima">Sudah Diterima</option>
                        <option value="gagal dikirim">Gagal Dikirim</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="courierNote">Catatan Kurir (Opsional)</label>
                    <textarea id="courierNote" name="courierNote"></textarea>
                </div>
                
                <div class="form-buttons">
                    <button type="button" class="btn-cancel">Batal</button>
                    <button type="submit" class="btn-save">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Store the delivery data in JavaScript for easy access
        const deliveries = <?= json_encode($deliveries) ?>;
        
        // Get DOM elements
        const modal = document.getElementById('statusModal');
        const closeBtn = document.querySelector('.close');
        const cancelBtn = document.querySelector('.btn-cancel');
        const detailBtns = document.querySelectorAll('.btn-detail');
        
        // Add event listeners to all detail buttons
        detailBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const deliveryId = parseInt(this.getAttribute('data-id'));
                openDeliveryModal(deliveryId);
            });
        });
        
        // Close modal when clicking close button or cancel button
        closeBtn.addEventListener('click', closeModal);
        cancelBtn.addEventListener('click', closeModal);
        
        // Close modal when clicking outside of it
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                closeModal();
            }
        });
        
        // Function to open the modal with delivery details
        function openDeliveryModal(deliveryId) {
            // Find the delivery in our data
            const delivery = deliveries.find(d => d.id === deliveryId);
            
            if (!delivery) {
                console.error('Delivery not found:', deliveryId);
                return;
            }
            
            console.log('Found delivery:', delivery); // Debugging
            
            // Get order details for this delivery
            fetchOrderDetails(delivery.pemesanan_id)
                .then(orderDetails => {
                    // Populate form fields
                    document.getElementById('deliveryId').value = delivery.id;
                    document.getElementById('customerName').value = delivery.nama_pelanggan;
                    document.getElementById('orderDetails').value = orderDetails;
                    document.getElementById('deliveryAddress').value = delivery.alamat_pengiriman;
                    
                    // Set current status
                    const statusSelect = document.getElementById('deliveryStatus');
                    for (let i = 0; i < statusSelect.options.length; i++) {
                        if (statusSelect.options[i].value === delivery.status_pengiriman) {
                            statusSelect.selectedIndex = i;
                            break;
                        }
                    }
                    
                    // Set current note
                    document.getElementById('courierNote').value = delivery.catatan || '';
                    
                    // Show modal
                    modal.style.display = 'block';
                })
                .catch(error => {
                    console.error('Error in openDeliveryModal:', error);
                    alert('Terjadi kesalahan saat memuat detail pesanan');
                });
        }
        
        // Function to close the modal
        function closeModal() {
            modal.style.display = 'none';
        }
        
        // Function to fetch order details
        async function fetchOrderDetails(pemesananId) {
            console.log('Fetching details for order ID:', pemesananId); // Debugging
            
            if (!pemesananId) {
                console.error('Invalid pemesanan_id:', pemesananId);
                return 'ID pesanan tidak valid';
            }
            
            try {
                const response = await fetch(`../logic/admin/kurir.php?id=${pemesananId}`);
                
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                console.log('API response:', data); // Debugging
                
                if (data.success) {
                    return data.details;
                } else {
                    console.error('API error:', data.message);
                    return data.message || 'Tidak ada detail pesanan';
                }
            } catch (error) {
                console.error('Error fetching order details:', error);
                return 'Error loading order details: ' + error.message;
            }
        }
    });
    
    // Confirmation function for delete
    function confirmDelete() {
        return confirm('Apakah Anda yakin ingin menghapus semua data pengiriman dengan status "sudah diterima"?');
    }
    </script>
</body>
</html>