<?php
include '../config/db.php';
$totalPesananQuery = "SELECT COUNT(*) as total FROM pesanan";
$totalPendingQuery = "SELECT COUNT(*) as total FROM pemesanan WHERE status = 'pending' OR status = 'sedang diproses'";
$totalSelesaiQuery = "SELECT COUNT(*) as total FROM pemesanan WHERE status = 'selesai'";

$totalPesanan = $conn->query($totalPesananQuery)->fetch_assoc()['total'];
$totalPending = $conn->query($totalPendingQuery)->fetch_assoc()['total'];
$totalSelesai = $conn->query($totalSelesaiQuery)->fetch_assoc()['total'];

// Pagination setup
$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$startFrom = ($page - 1) * $limit;

$pesananQuery = "
    SELECT 
        pesanan.*, 
        users.username AS nama_user, 
        produk.nama,
        pemesanan.status AS status_pemesanan
    FROM 
        pesanan 
    JOIN users ON pesanan.user_id = users.id 
    JOIN produk ON pesanan.produk_id = produk.id 
    LEFT JOIN pemesanan ON pesanan.id = pemesanan.pesanan_id
    ORDER BY pesanan.tanggal_pesan DESC 
    LIMIT $startFrom, $limit
";

$pesananResult = $conn->query($pesananQuery);

// Untuk pagination info
$totalPagesQuery = "SELECT COUNT(*) as total FROM pesanan";
$totalRows = $conn->query($totalPagesQuery)->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="icon" href="../assets/icon/logo.png" type="image/png">

    <style>
        .status-cell {
            font-weight: bold;
        }
        .status-pending {
            color: #ff9800;
        }
        .status-sedang-diproses {
            color: #2196F3;
        }
        .status-selesai {
            color: #4CAF50;
        }
        .status-dibatalkan {
            color: #f44336;
        }
    </style>

    <style>
    .btn-sembunyi-selesai {
        background-color: #f57c00;
        color: white;
        padding: 8px 15px;
        border: none;
        border-radius: 5px;
        margin-bottom: 10px;
        cursor: pointer;
        font-weight: bold;
    }

    .btn-sembunyi-selesai:hover {
        background-color: #e65100;
    }
    </style>

</head>
<body>
    <?php include '../pages/include/sidebar.php'; ?>

    <main class="dashboard-content">
        <div class="dashboard-header">
            <h1>Dashboard</h1>
        </div>

    <div class="stats-container">
        <div class="stats-card">
            <h3>Total Pesanan Masuk</h3>
            <div class="stats-number"><?= $totalPesanan ?></div>
        </div>
        <div class="stats-card">
            <h3>Diproses</h3>
            <div class="stats-number"><?= $totalPending ?></div>
        </div>
        <div class="stats-card">
            <h3>Selesai</h3>
            <div class="stats-number"><?= $totalSelesai ?></div>
        </div>
    </div>

    <button onclick="sembunyikanBarisSelesai()" class="btn-sembunyi-selesai">
        Sembunyikan Semua Pesanan Selesai
    </button>


        <div class="table-container">
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pemesan</th>
                        <th>Nama Pesanan</th>
                        <th>Jumlah</th>
                        <th>Jenis Martabak</th>
                        <th>Varian Martabak</th>
                        <th>Catatan</th>
                        <th>Alamat</th>
                        <th>Bukti Pembayaran</th>
                        <th>Status</th>
                        
                    </tr>
                </thead>
                <tbody>
                <?php 
$no = $startFrom + 1;
while ($row = $pesananResult->fetch_assoc()) : 
    // Ambil pesanan_id dari tabel pesanan
    $pesanan_id = $row['pesanan_id'] ?? $row['id']; // fallback ke id pesanan kalau pesanan_id tidak ada

    // Query status dari tabel pemesanan
    $statusResult = $conn->query("SELECT status FROM pemesanan WHERE id = $pesanan_id LIMIT 1");
    $statusData = $statusResult->fetch_assoc();
    $status = $statusData['status'] ?? 'pending';

    $statusClass = '';
    switch($status) {
        case 'pending':
            $statusClass = 'status-pending';
            break;
        case 'sedang diproses':
            $statusClass = 'status-sedang-diproses';
            break;
        case 'selesai':
            $statusClass = 'status-selesai';
            break;
        case 'dibatalkan':
            $statusClass = 'status-dibatalkan';
            break;
    }

    
?>


    <tr class="<?= ($status === 'selesai') ? 'baris-selesai' : '' ?>">
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama_user']) ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= $row['jumlah'] ?></td>
        <td><?= $row['jenis_martabak'] ?></td>
        <td><?= $row['varian_martabak'] ?></td>
        <td><?= htmlspecialchars($row['catatan']) ?></td>
        <td><?= htmlspecialchars($row['alamat']) ?></td>
        <td>
            <?php if (!empty($row['bukti_pembayaran'])): ?>
                <a href="../buktiPembayaran/<?= urlencode($row['bukti_pembayaran']) ?>" target="_blank">
                    Lihat Bukti
                </a>
            <?php else: ?>
                Belum Ada
            <?php endif; ?>
        </td>
        <td class="status-cell <?= $statusClass ?>">
            <?= ucfirst($status) ?>
        </td>

        <!-- Hidden input untuk simpan pesanan_id -->
        <input type="hidden" name="pesanan_id" value="<?= $pesanan_id ?>">

    </tr>
<?php endwhile; ?>


                </tbody>
            </table>
        </div>

        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>" class="btn-page">&laquo; Prev</a>
            <?php endif; ?>

            <span class="page-info">Page <?= $page ?> of <?= $totalPages ?></span>

            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page + 1 ?>" class="btn-page">Next &raquo;</a>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>

<script>
function sembunyikanBarisSelesai() {
    const barisSelesai = document.querySelectorAll('.baris-selesai');
    barisSelesai.forEach(row => {
        row.style.display = 'none';
    });
}
</script>
